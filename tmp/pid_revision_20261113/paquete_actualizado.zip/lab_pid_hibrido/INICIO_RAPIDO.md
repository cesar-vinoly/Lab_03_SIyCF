# PID clasico e hibrido: motor y planta termica

## 1. Elegir el archivo de la placa

| Planta | Archivo independiente | Controladores incluidos |
|---|---|---|
| Motor DC | `main_motor.c` | PID fijo y PID hibrido TSK-1 |
| Planta termica | `main_planta_termica.c` | PI fijo y PI hibrido TSK-1; Kd = 0 |

Cada archivo contiene todo el firmware: configuracion, controlador, sensor,
interrupciones, PWM y comunicacion. No necesita los otros archivos C ni H.
Se escribe en C para AVR-GCC, ATmega328P a 16 MHz, sin framework Arduino.
Conservar la extension `.c`; no es un sketch `.ino` ni un `main.cpp` de Arduino.

Abrir ESTA carpeta completa en PlatformIO. El `platformio.ini` incluido compila
solo el archivo correspondiente al entorno elegido:

```powershell
pio run -e motor -t upload --upload-port COM7
pio run -e termica -t upload --upload-port COM10
```

Los puertos son ejemplos. Ejecutar solo la orden que corresponda a cada placa.
Si se utiliza otro proyecto AVR sin Arduino, copiar el archivo elegido como
`src/main.c`, compilando solo ese archivo. No agregar ademas `control.c` ni otro `main`.

No hay que volver a cargar firmware para alternar PID/HYB: Python selecciona el
modo antes de cada ensayo. Al arrancar, la salida permanece apagada hasta recibir
START. El codigo necesita la captura activa, que envia PING; ante perdida de enlace
apaga la salida. Cerrar el monitor serie de PlatformIO antes de capturar.

| Parametro | Motor | Planta termica |
|---|---:|---:|
| Kp nominal | 0.8356 | 1.286 |
| Ki nominal | 5.498 | 0.01565 |
| Kd nominal | 0.03175 | 0 |
| Muestreo | 20 ms | 1 s |
| Baudios | 115200 | 9600 |
| Actuacion | D9; PWM 0 a 255 | D5; potencia hasta 45 % nominal |
| Sensor | Encoder D2; 63.9 pulsos/vuelta | LM35 A0; referencia ADC 5 V nominal |
| Direccion L298N | IN1 D7; IN2 D8 | No aplica |

Las ganancias, pines y limites conservan los del paquete anterior.

## 2. Instalar Python y dependencias

Abrir una terminal en esta carpeta extraida. Con el interprete utilizado en tus ensayos:

```powershell
& "C:\Python314\python.exe" -m pip install -r requirements.txt
```

Conservar juntos `capturar_motor.py`, `capturar_termica.py`, `capturar.py`,
`comparar.py` y `metricas.py`. Los scripts especificos utilizan esos modulos comunes.

## 3. Capturar el motor

Realizar primero un ensayo y luego el otro, partiendo del motor detenido, con
la misma carga y alimentacion. Se registran 2 s de reposo y 30 s de control a 80 rpm.

```powershell
& "C:\Python314\python.exe" capturar_motor.py --puerto COM7 --modo PID --referencia 80 --duracion 30 --salida datos/motor_pid.csv
& "C:\Python314\python.exe" capturar_motor.py --puerto COM7 --modo HYB --referencia 80 --duracion 30 --salida datos/motor_hibrido.csv
& "C:\Python314\python.exe" comparar.py datos/motor_pid.csv datos/motor_hibrido.csv --planta motor --salida comparacion_motor
```

## 4. Capturar la planta termica

Hacer los ensayos por separado. Antes del segundo, dejar enfriar hasta una condicion
inicial equivalente a la del primero. Los 20 s de reposo registrados por el firmware
no garantizan ese enfriamiento. Se registran 600 s de control a 45 C.

```powershell
& "C:\Python314\python.exe" capturar_termica.py --puerto COM10 --modo PID --referencia 45 --duracion 600 --salida datos/termica_pi.csv
& "C:\Python314\python.exe" capturar_termica.py --puerto COM10 --modo HYB --referencia 45 --duracion 600 --salida datos/termica_hibrido.csv
& "C:\Python314\python.exe" comparar.py datos/termica_pi.csv datos/termica_hibrido.csv --planta termica --salida comparacion_termica
```

Aqui `--modo PID` es el nombre del modo clasico del protocolo: el controlador
termico efectivo es PI porque Kd = 0. La comparacion es PI fijo frente a PI hibrido.

## 5. Archivos generados por cada captura

Para una captura llamada `motor_pid.csv`:

| Archivo | Contenido |
|---|---|
| `motor_pid.csv` | Todas las muestras originales, incluido reposo y cierre |
| `motor_pid.json` | Planta, modo, unidades, muestreo, duracion y estado de captura |
| `motor_pid.log` | Mensajes y eventos recibidos |
| `motor_pid_errores.csv` | Tiempo de control, ref, y, e, abs(e), e^2, t*abs(e), IAE/ISE/ITAE acumulados |
| `motor_pid_metricas.csv` | Indicadores finales de ese ensayo |
| `motor_pid_metricas.json` | Indicadores, unidades y criterio de integracion |

Las columnas originales son:

`t_s,phase,mode,segment,ref,y,u,error,kp,ki,kd,control_us,missed,tx_dropped`

- `t_s`: tiempo programado por el temporizador desde que empieza el registro.
- `phase`: 0 = reposo; 1 = control; 2 = muestra final y apagado.
- `error`: referencia menos medicion. Python lo comprueba y lo recalcula para integrar.
- `u`: PWM realmente aplicado (motor) o porcentaje de potencia (termica).
- `kp,ki,kd`: ganancias efectivamente utilizadas en cada instante.
- `control_us`: duracion instrumentada del lazo; `missed` y `tx_dropped`: incidencias.

El periodo se obtiene de los tiempos del CSV. No se utiliza el tiempo de llegada
del USB para integrar. En `_errores.csv`, t=0 corresponde al inicio del control.
Las capturas interrumpidas conservan sus datos y metadatos, pero no se presentan
como ensayos completos ni se generan sus indicadores finales automaticamente.
No se sobrescriben capturas existentes. Para repetir, elegir otro nombre.

## 6. Indicadores de la imagen

Sea e[k] = ref[k] - y[k], t[0] = 0 en el inicio del control y dt[k] = t[k+1]-t[k].
Se aplican trapecios sobre las muestras medidas:

```text
IAE  = suma dt[k] * (abs(e[k]) + abs(e[k+1])) / 2
ISE  = suma dt[k] * (e[k]^2 + e[k+1]^2) / 2
ITAE = suma dt[k] * (t[k]*abs(e[k]) + t[k+1]*abs(e[k+1])) / 2
```

El reposo inicial queda fuera de las integrales. La muestra final mide la planta
antes de apagar y aporta el extremo T de integracion: 30 s o 600 s en estos ejemplos.
El cambio a salida cero en esa fila no se incluye en la variacion del PWM del ensayo.

| Indicador | Motor | Planta termica |
|---|---|---|
| IAE | rpm*s | C*s |
| ISE | rpm^2*s | C^2*s |
| ITAE | rpm*s^2 | C*s^2 |

Para comparar, usar misma planta, referencia, duracion, muestreo y condiciones
iniciales. Menor IAE/ISE/ITAE significa menor error segun ese criterio dentro de
ese intervalo; no son porcentajes. No comparar directamente indices de plantas
distintas porque cambian las unidades y los horizontes.

## 7. Resultado de la comparacion

`comparar.py` genera:

- `metricas.csv` y `metricas.json`: valores clasico/hibrido y reduccion porcentual
  de cada indice: 100*(clasico-hibrido)/clasico. Positivo = disminucion; negativo =
  aumento. Si el clasico vale cero, el porcentaje no se define y queda vacio/null.
- `comparacion.png`: medicion y referencia, actuacion y error.
- `ganancias.png`: Kp, Ki y Kd durante los dos ensayos.
- `indicadores_integrales.png`: evolucion de IAE, ISE e ITAE acumulados.
- `comparacion_indices.png`: comparacion de los tres valores finales.
- `errores_clasico.csv` y `errores_hibrido.csv`: detalle de los calculos.

Tambien calcula sobreimpulso, subida 10-90 %, establecimiento en banda del 2 %,
error medio del ultimo 10 %, esfuerzo integral y variacion del PWM. El error final
no prueba por si mismo que se haya alcanzado regimen estacionario. Un indicador
temporal no alcanzado o no aplicable se deja vacio/null.

Se rechazan muestras perdidas, tiempos duplicados, capturas incompletas o diferencias
en horizonte/referencia/muestreo. La tolerancia inicial por defecto es 0.5 rpm o C.
La igualdad de una medicion inicial no garantiza igualdad de estados internos:
conservar tambien temperatura de partida, alimentacion, carga y perturbaciones.

Los ensayos incluidos en `simulaciones/` son teoricos y estan identificados como
SIMULACION. No reemplazan las mediciones del montaje ni demuestran una mejora real.

## 8. Modificaciones y verificacion

Si se usa el proyecto incluido, editar el `main` de la planta correspondiente.
El firmware modular original se conserva en `firmware/`. Como alternativa, editar
ese firmware y ejecutar `python generar_main_independientes.py`; esto SOBRESCRIBE
ambos archivos independientes con el contenido modular.

`python pruebas.py` comprueba el protocolo con puertos simulados y los indices con
senales de resultado conocido. No abre puertos fisicos ni acciona las plantas.
Ver `VERIFICACION.md` para el alcance de las comprobaciones de esta version.

# Verificacion de esta entrega

## Actualizacion del 13/11/2026: main independientes y captura de indicadores

- Agregados `main_motor.c` y `main_planta_termica.c`, cada uno autocontenido.
  Se verifica que incluyen exactamente el contenido del firmware modular anterior
  sin sus includes locales. No se modificaron las ecuaciones de control ni los pines.
- `capturar_motor.py` y `capturar_termica.py` seleccionan la planta y permiten PID/HYB.
  Las capturas completas exportan automaticamente indicadores y errores acumulados.
- Corregida la recepcion de lineas fragmentadas por timeout del puerto serie.
- Pruebas Python aprobadas: 20 combinaciones de planta/modo/captura normal,
  fragmentada, con huecos, planta incorrecta y error corrupto; verificacion de STOP,
  archivos derivados y metadatos; rechazo de comparaciones con diferentes
  referencias, horizontes, modos o mediciones iniciales.
- Integracion comprobada con error constante positivo, negativo y cero, y origen
  temporal desplazado. Para e=2 durante 10 s: IAE=20, ISE=40, ITAE=100.
- Comparador ejecutado sobre los CSV teoricos del escalon de ambas plantas.
  Exporta las tablas, errores acumulados y cuatro figuras por comparacion.
  Los resultados se conservan bajo `simulaciones/verificacion_revision_*`.

Limitacion de compilacion en esta actualizacion: el AVR-GCC local no pudo iniciarse
por un error de reasignacion de DLL de Windows. Por tanto no se afirma una nueva
compilacion de los archivos independientes. Los HEX y ELF de `build/` son los
anteriores, conservados sin cambios; la tabla de memoria que sigue pertenece a
aquella compilacion del firmware modular. `compilar.ps1` y PlatformIO estan
configurados para compilar los archivos independientes en el equipo del usuario.

No se abrieron puertos COM fisicos ni se cargaron placas. Faltan las mediciones
reales y la comprobacion de periodicidad, tiempo de ISR y respuesta del montaje.

## Registro de la compilacion anterior (firmware modular)

Firmware compilado con AVR-GCC 7.3.0, -std=gnu11 -Os -Wall -Wextra -Werror; cero advertencias.

| Planta | Programa [bytes] | RAM estatica [bytes] |
|---|---:|---:|
| Motor | 11996 | 423 |
| Termica | 11792 | 413 |

La RAM estatica no incluye el maximo de pila. No se midio el peor tiempo real de ISR.

Pruebas numericas y de protocolo: cobertura de pertenencias, limites de ganancias, anti-windup, integrales con senal conocida, captura normal, rechazo de huecos, rechazo de planta incorrecta y envio de STOP. No se abrieron puertos fisicos.

Resultados del escalon en simulacion ideal (no experimentales):

| Planta | Modo | IAE | Sobreimpulso [%] | Establecimiento [s] |
|---|---|---:|---:|---:|
| motor | PID | 39.9383 | 17.9852 | 2.18 |
| motor | HYB | 40.2580 | 16.8919 | 2.2 |
| termica | PID | 1236.6413 | 6.6263 | 435.0 |
| termica | HYB | 1236.5940 | 6.9203 | 437.0 |

El hibrido no mejora todos los indicadores. Son reglas iniciales para validar y ajustar en banco.
Se conserva Kd=0 en termica: PI fijo frente a PI hibrido.
Ver los supuestos del modelo termico, filtros y escalas en LEEME.md.

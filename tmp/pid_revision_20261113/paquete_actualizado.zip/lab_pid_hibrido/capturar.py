"""Captura firmware AVR del laboratorio. No carga ni modifica el firmware."""
import argparse
import csv
import json
from datetime import datetime
from pathlib import Path
import time
import math
from metricas import export_single, single_output_paths

FIELDS = 't_s,phase,mode,segment,ref,y,u,error,kp,ki,kd,control_us,missed,tx_dropped'.split(',')

class LineReader:
    """Conserva fragmentos entre timeouts; entrega solo lineas completas."""
    def __init__(self, port):
        self.port = port
        self.pending = bytearray()

    def readline(self):
        self.pending.extend(self.port.readline())
        if len(self.pending) > 1024:
            raise RuntimeError('Linea serie demasiado larga o sin terminador.')
        if b'\n' not in self.pending:
            return ''
        line, _, rest = self.pending.partition(b'\n')
        self.pending = bytearray(rest)
        return line.decode('ascii', errors='strict').strip()


def main(planta_fija=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--puerto', required=True)
    if planta_fija:
        p.set_defaults(planta=planta_fija)
    else:
        p.add_argument('--planta', choices=['motor', 'termica'], required=True)
    p.add_argument('--modo', choices=['PID', 'HYB'], required=True)
    p.add_argument('--referencia', type=float, default=None, help='Por defecto: motor 80 rpm; termica 45 C')
    p.add_argument('--duracion', type=int, default=None, help='Segundos de control, sin reposo inicial')
    p.add_argument('--cambio', action='append', default=[], metavar='SEGUNDOS:REFERENCIA')
    p.add_argument('--salida', type=Path)
    a = p.parse_args()
    import serial
    if a.referencia is None:
        a.referencia = 80 if a.planta == 'motor' else 45
    maximum = 120 if a.planta == 'motor' else 70
    duration = a.duracion if a.duracion is not None else (30 if a.planta == 'motor' else 600)
    if not math.isfinite(a.referencia) or not 0 <= a.referencia <= maximum or not 1 <= duration <= 3600:
        p.error('Referencia o duracion fuera de rango.')
    changes = []
    for text in a.cambio:
        try:
            seconds, value = map(float, text.split(':'))
        except ValueError:
            p.error('Usar --cambio SEGUNDOS:REFERENCIA; por ejemplo --cambio 10:90.')
        if not (math.isfinite(seconds) and math.isfinite(value) and 0 < seconds < duration and 0 <= value <= maximum):
            p.error('Cambio fuera de rango.')
        changes.append((seconds, value))
    changes.sort()
    if len({x[0] for x in changes}) != len(changes):
        p.error('No repetir el instante de cambio.')
    baud = 115200 if a.planta == 'motor' else 9600
    baseline = 2 if a.planta == 'motor' else 20
    sample_period = 0.02 if a.planta == 'motor' else 1.0
    output = a.salida or Path('datos') / f'{a.planta}_{a.modo}_{datetime.now():%Y%m%d_%H%M%S}.csv'
    if output.suffix.lower() != '.csv':
        p.error('--salida debe terminar en .csv.')
    output.parent.mkdir(parents=True, exist_ok=True)
    log_path, meta_path = output.with_suffix('.log'), output.with_suffix('.json')
    if any(x.exists() for x in [output, log_path, meta_path, *single_output_paths(output)]):
        p.error('Ya existe un archivo de salida. Usar otro nombre.')
    meta = dict(planta=a.planta, modo=a.modo, referencia=a.referencia, duracion_s=duration,
                baseline_s=baseline, puerto=a.puerto, baud=baud, cambios=changes,
                Ts_s=sample_period, unidad_y='rpm' if a.planta == 'motor' else 'C',
                unidad_u='PWM_0_255' if a.planta == 'motor' else 'porcentaje',
                inicio=datetime.now().astimezone().isoformat(), estado='incompleto', filas=0)
    ser = None
    failure = None
    try:
        with output.open('x', newline='', encoding='utf-8') as f, log_path.open('x', encoding='utf-8') as log:
            writer = csv.writer(f)
            writer.writerow(FIELDS)
            ser = serial.Serial(a.puerto, baud, timeout=0.1, write_timeout=1)
            reader = LineReader(ser)
            time.sleep(2)  # Reinicio normal del Uno al abrir el puerto.
            ser.reset_input_buffer()
            ser.write(b'?\n')
            deadline = time.monotonic() + 6
            ready = False
            while time.monotonic() < deadline:
                text = reader.readline()
                if text:
                    log.write(text + '\n')
                if text.startswith('#READY '):
                    if not text.startswith('#READY ' + a.planta + ' '):
                        raise RuntimeError('El firmware conectado corresponde a otra planta.')
                    config = dict(part.split('=', 1) for part in text.split()[2:] if '=' in part)
                    if float(config.get('Ts_ms', -1)) != sample_period * 1000 or int(config.get('baud', -1)) != baud:
                        raise RuntimeError('El muestreo o los baudios del firmware no coinciden.')
                    meta['firmware_ready'] = text
                    ready = True
                if text == ','.join(FIELDS) and ready:
                    break
            else:
                raise RuntimeError('No se recibio la cabecera del firmware nuevo.')
            ser.write(f'START {a.modo} {a.referencia:.6f} {duration}\n'.encode('ascii'))
            started = time.monotonic()
            next_ping, next_display, change_index = started, 0, 0
            previous_t = None
            last_phase = None
            last_data = started
            while time.monotonic() - started < baseline + duration + 30:
                now = time.monotonic()
                if now >= next_ping:
                    ser.write(b'PING\n')
                    next_ping = now + 1
                text = reader.readline()
                if not text:
                    if now - last_data > 6:
                        raise RuntimeError('Se interrumpio la recepcion de muestras.')
                    continue
                if text.startswith('#'):
                    log.write(text + '\n'); log.flush()
                    print(text)
                    if text.startswith('#ERROR'):
                        raise RuntimeError(text)
                    if text.startswith('#FIN '):
                        meta['codigo_fin'] = int(text.split()[1])
                        if meta['codigo_fin'] != 5:
                            raise RuntimeError('Ensayo detenido antes del final normal; consultar el .log.')
                        if last_phase != 2 or previous_t is None or abs(previous_t-baseline-duration)>1e-5:
                            raise RuntimeError('Faltan muestras o el horizonte recibido no coincide con el solicitado.')
                        meta['estado'] = 'completo'
                        break
                    continue
                values = next(csv.reader([text]))
                if values == FIELDS:
                    raise RuntimeError('Se detecto un reinicio o una cabecera inesperada.')
                if len(values) != len(FIELDS):
                    raise RuntimeError('Fila incompleta; no se rellenan muestras faltantes.')
                row = dict(zip(FIELDS, values))
                if not all(math.isfinite(float(row[key])) for key in FIELDS if key != 'mode'):
                    raise RuntimeError('Fila con valores no finitos.')
                if row['mode'] != a.modo:
                    raise RuntimeError('Modo recibido diferente del solicitado.')
                if abs(float(row['error']) - (float(row['ref']) - float(row['y']))) > 0.0021:
                    raise RuntimeError('El error recibido no coincide con referencia menos medicion.')
                t = float(row['t_s'])
                if previous_t is not None and t <= previous_t:
                    raise RuntimeError('Tiempo repetido o reinicio del microcontrolador.')
                if previous_t is None and abs(t)>1e-5:
                    raise RuntimeError('Falta la primera muestra.')
                if previous_t is not None and abs(t-previous_t-sample_period)>1e-5:
                    raise RuntimeError('Se detecto un hueco en el muestreo.')
                last_phase = int(row['phase'])
                expected_phase = 0 if t < baseline else (1 if t < baseline + duration else 2)
                if float(row['phase']) != expected_phase:
                    raise RuntimeError('La fase recibida no coincide con el instante del ensayo.')
                previous_t, last_data = t, now
                writer.writerow(values); f.flush(); meta['filas'] += 1
                if int(row['missed']) or int(row['tx_dropped']):
                    raise RuntimeError('Se detectaron plazos incumplidos o muestras perdidas.')
                elapsed = t - baseline
                if change_index < len(changes) and int(row['phase']) == 1 and elapsed >= changes[change_index][0]:
                    ser.write(f'REF {changes[change_index][1]:.6f}\n'.encode('ascii'))
                    log.write(f'#CAMBIO_SOLICITADO t_s={t} ref={changes[change_index][1]}\n')
                    change_index += 1
                if t >= next_display:
                    print(f"t={t:7.2f}s  r={row['ref']}  y={row['y']}  u={row['u']}")
                    next_display = t + 1
            else:
                raise RuntimeError('No se recibio el final del ensayo.')
    except KeyboardInterrupt:
        failure = 'Interrumpido por el usuario.'
        meta['estado'] = 'interrumpido'
    except Exception as exc:
        failure = str(exc)
        meta['error'] = failure
    finally:
        if ser is not None:
            try:
                ser.write(b'STOP\n'); ser.flush()
            except Exception:
                pass
            ser.close()
        meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding='utf-8')
    print(f'CSV: {output.resolve()}')
    if failure:
        raise SystemExit(failure)
    result = export_single(output, a.planta)
    print(f"IAE={result['IAE']:.6g}  ISE={result['ISE']:.6g}  ITAE={result['ITAE']:.6g}")
    print('Indices y errores acumulados:')
    for path in single_output_paths(output):
        print(path.resolve())

if __name__ == '__main__':
    main()

"""Captura del motor: PID clasico o hibrido; por defecto 80 rpm durante 30 s."""
from capturar import main

if __name__ == '__main__':
    main(planta_fija='motor')

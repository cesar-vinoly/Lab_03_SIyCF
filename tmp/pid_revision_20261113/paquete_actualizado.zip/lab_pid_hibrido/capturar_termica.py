"""Captura termica: PI clasico o hibrido; por defecto 45 C durante 600 s."""
from capturar import main

if __name__ == '__main__':
    main(planta_fija='termica')

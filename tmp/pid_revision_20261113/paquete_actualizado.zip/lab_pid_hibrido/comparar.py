"""Compara PID/PI fijo y TSK-1; exporta indices, curvas y errores acumulados."""
from metricas import main

if __name__ == '__main__':
    main()

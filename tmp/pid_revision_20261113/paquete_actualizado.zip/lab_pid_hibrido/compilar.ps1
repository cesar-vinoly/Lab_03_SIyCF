param([string]$AvrBin = "$env:USERPROFILE\.platformio\packages\toolchain-atmelavr\bin")
$ErrorActionPreference = 'Stop'
$ProjectDir = $PSScriptRoot
$BuildDir = Join-Path $ProjectDir 'build'
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
$Compiler = Join-Path $AvrBin 'avr-gcc.exe'
if (-not (Test-Path -LiteralPath $Compiler)) { throw "No se encontro AVR-GCC en $AvrBin" }
foreach ($Plant in @('motor','termica')) {
    $Source = if ($Plant -eq 'motor') { 'main_motor.c' } else { 'main_planta_termica.c' }
    $Elf = Join-Path $BuildDir "$Plant.elf"
    $Hex = Join-Path $BuildDir "$Plant.hex"
    & $Compiler -mmcu=atmega328p -DF_CPU=16000000UL -std=gnu11 -Os -Wall -Wextra -Werror -ffunction-sections -fdata-sections "-Wl,--gc-sections" (Join-Path $ProjectDir $Source) -lm -o $Elf
    if ($LASTEXITCODE -ne 0) { throw "Error compilando $Plant" }
    & (Join-Path $AvrBin 'avr-objcopy.exe') -O ihex -R .eeprom $Elf $Hex
    if ($LASTEXITCODE -ne 0) { throw "Error generando $Hex" }
    & (Join-Path $AvrBin 'avr-size.exe') -C --mcu=atmega328p $Elf
}

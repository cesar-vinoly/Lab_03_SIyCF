#ifndef CONFIG_H
#define CONFIG_H
#ifndef PLANTA_MOTOR
#error "Definir PLANTA_MOTOR=1 (motor) o PLANTA_MOTOR=0 (termica)."
#endif
#if PLANTA_MOTOR
#define PLANT_NAME "motor"
#define UART_BAUD 115200UL
#define SAMPLE_MS 20UL
#define BASELINE_MS 2000UL
#define KP0 0.8356f
#define KI0 5.498f
#define KD0 0.03175f
#define UMAX 255.0f
#define REF_MAX 120.0f
#define EMAX 120.0f
/* Maximo simulado nominal 0->120 rpm: 12.045 rpm/muestra; margen a 15. */
#define DEMAX 15.0f
#define DELTA_ALPHA (0.02f / (0.04f + 0.02f))
#define GAIN_BETA (0.02f / (0.10f + 0.02f))
#define ENCODER_PPR 63.9f
#define ENCODER_TIMEOUT_US 300000UL
#else
#define PLANT_NAME "termica"
#define UART_BAUD 9600UL
#define SAMPLE_MS 1000UL
#define BASELINE_MS 20000UL
#define KP0 1.286f
#define KI0 0.01565f
/* PI nominal y PI hibrido: no se inventa una ganancia derivativa. */
#define KD0 0.0f
#define UMAX 45.0f
#define REF_MAX 70.0f
#define EMAX 40.0f
/* Maximo simulado nominal 20->60 C: 0.347 C/muestra; margen a 0.5. */
#define DEMAX 0.5f
#define DELTA_ALPHA (1.0f / (4.0f + 1.0f))
#define GAIN_BETA (1.0f / (5.0f + 1.0f))
#define ADC_REFERENCE_MV 5000UL
#define ADC_SAMPLES 16U
#define TEMPERATURE_LIMIT 80.0f
#endif
#define LINK_TIMEOUT_US 5000000UL
#define MAX_DURATION_S 3600UL
#endif

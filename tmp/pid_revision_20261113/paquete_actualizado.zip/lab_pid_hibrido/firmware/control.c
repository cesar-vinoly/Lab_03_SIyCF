#include "control.h"
#include <math.h>

static float clip(float x, float lo, float hi) {
    return x < lo ? lo : (x > hi ? hi : x);
}

/* Triangulos Ruspini, con hombros: sum(mu)=1 incluso en +/-1.
   Centros del error: -1,-0.5,0,0.5,1. De la variacion: -1,0,1.
   A lo sumo se activan cuatro de las quince reglas por muestra. */
static void memberships(float x, uint8_t n, float *mu) {
    uint8_t i;
    float position;
    for (i=0; i<n; ++i) mu[i]=0.0f;
    x=clip(x,-1.0f,1.0f);
    if (x<=-1.0f) { mu[0]=1.0f; return; }
    if (x>=1.0f) { mu[n-1]=1.0f; return; }
    position=(x+1.0f)*(float)(n-1)*0.5f;
    i=(uint8_t)position;
    mu[i+1]=position-(float)i;
    mu[i]=1.0f-mu[i+1];
}

void fuzzy_corrections(float en, float den, float out[3]) {
    float me[5], md[3], sum=0.0f;
    uint8_t i,j;
    en=clip(en,-1.0f,1.0f); den=clip(den,-1.0f,1.0f);
    memberships(en,5,me); memberships(den,3,md);
    out[0]=out[1]=out[2]=0.0f;
    for (i=0; i<5; ++i) {
        const float se=i<2 ? -1.0f : (i>2 ? 1.0f : 0.0f);
        if (me[i]==0.0f) continue;
        for (j=0; j<3; ++j) {
            const float sd=j==0 ? -1.0f : (j==2 ? 1.0f : 0.0f);
            const float w=me[i]*md[j];
            if (w==0.0f) continue;
            /* Consecuentes afines TSK-1, no salidas singleton.
               Correcciones relativas; se convierten a DeltaK con Kq0.
               p: mayor reaccion con error grande o que aumenta.
               i: menos integracion lejos del objetivo/cambio rapido.
               d: pequeno aumento al cambiar rapidamente el error. */
            out[0]+=w*(0.12f*se*en+0.06f*se*den);
            out[1]+=w*(-0.12f*se*en-0.04f*sd*den+0.02f);
            out[2]+=w*(0.08f*sd*den);
            sum+=w;
        }
    }
    if (sum>1e-6f) { for(i=0;i<3;++i) out[i]/=sum; }
    else out[0]=out[1]=out[2]=0.0f; /* Respaldo nominal. */
}

void control_reset(Control *c, const ControlConfig *p, uint8_t hybrid, float error) {
    c->integral=0.0f; c->previous_error=error;
    c->filtered_delta=0.0f; c->hybrid=hybrid;
    c->kp=p->kp0; c->ki=p->ki0; c->kd=p->kd0; c->error=error;
}

float control_step(Control *c, const ControlConfig *p, float reference, float y) {
    float out[3], target, trial, v, derivative;
    const float error=reference-y;
    const float ilim=p->umax/(0.80f*p->ki0);
    c->filtered_delta+=p->alpha*((error-c->previous_error)-c->filtered_delta);
    c->previous_error=error; c->error=error;
    if(c->hybrid) {
        fuzzy_corrections(error/p->emax,c->filtered_delta/p->demax,out);
        target=clip(p->kp0+p->kp0*out[0],0.85f*p->kp0,1.20f*p->kp0);
        c->kp+=p->beta*(target-c->kp);
        target=clip(p->ki0+p->ki0*out[1],0.80f*p->ki0,1.10f*p->ki0);
        c->ki+=p->beta*(target-c->ki);
        target=clip(p->kd0+p->kd0*out[2],0.90f*p->kd0,1.15f*p->kd0);
        c->kd+=p->beta*(target-c->kd);
    } else { c->kp=p->kp0; c->ki=p->ki0; c->kd=p->kd0; }
    derivative=c->filtered_delta/p->ts;
    trial=clip(c->integral+p->ts*error,-ilim,ilim);
    v=c->kp*error+c->ki*trial+c->kd*derivative;
    /* Clamp + integracion condicional; misma logica en ambos modos. */
    if(!((v>p->umax && error>0.0f)||(v<p->umin && error<0.0f))) c->integral=trial;
    v=c->kp*error+c->ki*c->integral+c->kd*derivative;
    return clip(v,p->umin,p->umax);
}

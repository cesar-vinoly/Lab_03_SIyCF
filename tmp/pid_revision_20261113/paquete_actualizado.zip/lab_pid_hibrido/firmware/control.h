#ifndef CONTROL_H
#define CONTROL_H
#include <stdint.h>

typedef struct {
    float ts, kp0, ki0, kd0;
    float umin, umax, emax, demax, alpha, beta;
} ControlConfig;
typedef struct {
    float integral, previous_error, filtered_delta;
    float kp, ki, kd, error;
    uint8_t hybrid;
} Control;

void control_reset(Control *c, const ControlConfig *p, uint8_t hybrid, float error);
float control_step(Control *c, const ControlConfig *p, float reference, float y);
void fuzzy_corrections(float en, float den, float out[3]);
#endif

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <util/atomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "control.h"

#if !defined(__AVR_ATmega328P__) || F_CPU != 16000000UL
#error "Requiere ATmega328P a 16 MHz."
#endif

/* Todo el lazo se ejecuta en ISR. Dentro del calculo se permiten IRQ
   breves de encoder, reloj y RX; un guard impide reentrar al controlador. */
static const ControlConfig cfg={SAMPLE_MS/1000.0f,KP0,KI0,KD0,0.0f,UMAX,
    EMAX,DEMAX,DELTA_ALPHA,GAIN_BETA};
static Control controller;
static volatile uint32_t clock_overflows;
static volatile uint8_t control_busy, fault_code, run_active, stop_requested;
static volatile uint16_t deadline_misses;
static volatile uint32_t last_ping_us;
static volatile uint8_t end_notice;
static uint32_t run_ms, duration_ms;
static uint16_t segment;
static uint8_t hybrid, entered_control;
static float reference;

enum { CMD_NONE, CMD_START, CMD_REF };
static volatile struct { float ref; uint32_t duration; uint8_t hybrid,kind; } command;
#define RX_SIZE 64
static volatile uint8_t rx[RX_SIZE],rx_head,rx_tail,rx_error;
#define QUEUE_SIZE 4
typedef struct {
    uint32_t ms,exec_us;
    float ref,y,u,error,kp,ki,kd;
    uint16_t segment,missed,dropped;
    uint8_t phase,hybrid;
} Sample;
static volatile Sample queue[QUEUE_SIZE];
static volatile uint8_t qhead,qtail;
static volatile uint16_t tx_dropped;

#if PLANTA_MOTOR
static volatile uint32_t last_edge,edge_period;
static volatile uint8_t have_edge;
ISR(TIMER0_OVF_vect) { ++clock_overflows; }
#else
ISR(TIMER2_OVF_vect) { ++clock_overflows; }
#endif

static uint32_t clock_us(void) {
    uint32_t over;
    uint8_t count;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
        over=clock_overflows;
#if PLANTA_MOTOR
        count=TCNT0;
        if((TIFR0&_BV(TOV0)) && count<255) ++over;
#else
        count=TCNT2;
        if((TIFR2&_BV(TOV2)) && count<255) ++over;
#endif
    }
    return ((over<<8)+count)*4UL;
}

#if PLANTA_MOTOR
ISR(INT0_vect) {
    uint32_t now=clock_us(),dt=now-last_edge;
    if(have_edge && dt<100UL) return;
    if(have_edge) edge_period=dt;
    last_edge=now; have_edge=1;
}
#endif

/* Devuelve la actuacion realmente aplicada, incluida cuantizacion. */
static float actuator(float u) {
#if PLANTA_MOTOR
    uint8_t value=(uint8_t)(u+0.5f);
    if(value==0 || value==255) {
        TCCR1A&=(uint8_t)~(_BV(COM1A1)|_BV(COM1A0));
        if(value) PORTB|=_BV(PB1); else PORTB&=(uint8_t)~_BV(PB1);
    } else {
        OCR1A=value;
        TCCR1A|=_BV(COM1A1);
    }
    return (float)value;
#else
    uint16_t ticks=(uint16_t)(u*2.56f+0.5f);
    /* No superar UMAX por redondeo. */
    const uint16_t max_ticks=(uint16_t)(UMAX*2.56f);
    if(ticks>max_ticks) ticks=max_ticks;
    if(ticks==0 || ticks>=256) {
        TCCR0A&=(uint8_t)~(_BV(COM0B1)|_BV(COM0B0));
        if(ticks) PORTD|=_BV(PD5); else PORTD&=(uint8_t)~_BV(PD5);
    } else {
        OCR0B=(uint8_t)(ticks-1);
        TCCR0A|=_BV(COM0B1);
    }
    return (float)ticks*(100.0f/256.0f);
#endif
}

static float measurement(void) {
#if PLANTA_MOTOR
    uint32_t now,last,period;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { now=clock_us(); last=last_edge; period=edge_period; }
    uint32_t age=now-last;
    if(!period || age>=ENCODER_TIMEOUT_US) return 0.0f;
    if(age>period) period=age;
    return 60000000.0f/(ENCODER_PPR*(float)period);
#else
    uint32_t sum=0;
    uint8_t i;
    for(i=0;i<ADC_SAMPLES;++i) {
        ADCSRA|=_BV(ADSC);
        while(ADCSRA&_BV(ADSC)) { }
        sum+=ADC;
    }
    return ((float)sum*(ADC_REFERENCE_MV/10.0f))/(ADC_SAMPLES*1024.0f);
#endif
}

static void control_interrupt(void) {
    uint32_t start;
    float y,u=0.0f,r;
    uint8_t phase=0,finish=0,kind,next;
    if(control_busy) {
        ++deadline_misses; fault_code=1; (void)actuator(0.0f);
        return;
    }
    control_busy=1;
    PORTB|=_BV(PB4); /* D12: tiempo de ejecucion medible. */
    start=clock_us();
    kind=command.kind;
    if(kind==CMD_START) {
        reference=command.ref; duration_ms=command.duration;
        hybrid=command.hybrid; run_ms=0; segment=0;
        entered_control=0; run_active=1; stop_requested=0;
        fault_code=0; deadline_misses=0; tx_dropped=0;
    } else if(kind==CMD_REF && run_active) { reference=command.ref; ++segment; }
    command.kind=CMD_NONE;
    sei(); /* Encoder y relojes siguen atendidos durante float/ADC. */
    y=measurement();
#if !PLANTA_MOTOR
    if(y>=TEMPERATURE_LIMIT || y<1.0f || !isfinite(y)) fault_code=2;
#endif
    if(run_active) {
        uint32_t ping;
        ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { ping=last_ping_us; }
        if((uint32_t)(clock_us()-ping)>LINK_TIMEOUT_US) fault_code=3;
        r=reference;
        if(stop_requested || fault_code) finish=fault_code ? fault_code : 4;
        else if(run_ms>=BASELINE_MS+duration_ms) finish=5;
        if(!finish && run_ms>=BASELINE_MS) {
            phase=1;
            if(!entered_control) {
                control_reset(&controller,&cfg,hybrid,r-y);
                entered_control=1;
            }
            u=control_step(&controller,&cfg,r,y);
        } else if(!entered_control) control_reset(&controller,&cfg,hybrid,r-y);
        cli();
        if(fault_code) finish=fault_code; /* IRQ de plazo durante calculo. */
        if(finish) { u=0.0f; phase=2; run_active=0; end_notice=finish; }
        u=actuator(u);
        next=(qhead+1U)%QUEUE_SIZE;
        if(next==qtail) ++tx_dropped;
        else {
            volatile Sample *s=&queue[qhead];
            s->ms=run_ms; s->phase=phase; s->hybrid=hybrid; s->segment=segment;
            s->ref=r; s->y=y; s->u=u; s->error=r-y;
            s->kp=controller.kp; s->ki=controller.ki; s->kd=controller.kd;
            s->missed=deadline_misses; s->dropped=tx_dropped;
            s->exec_us=clock_us()-start; qhead=next;
        }
        run_ms+=SAMPLE_MS;
    } else { cli(); (void)actuator(0.0f); }
    PORTB&=(uint8_t)~_BV(PB4); control_busy=0;
}

#if PLANTA_MOTOR
ISR(TIMER2_COMPA_vect) {
    static uint8_t divider;
    if(++divider>=20) { divider=0; control_interrupt(); }
}
#else
ISR(TIMER1_COMPA_vect) { control_interrupt(); }
#endif

ISR(USART_RX_vect) {
    uint8_t status=UCSR0A,b=UDR0,next=(rx_head+1U)%RX_SIZE;
    if((status&(_BV(FE0)|_BV(DOR0)|_BV(UPE0))) || next==rx_tail) rx_error=1;
    else { rx[rx_head]=b; rx_head=next; }
}
static int uart_putchar(char c,FILE *stream) {
    (void)stream;
    while(!(UCSR0A&_BV(UDRE0))) { }
    UDR0=(uint8_t)c;
    return 0;
}
static FILE serial_output=FDEV_SETUP_STREAM(uart_putchar,NULL,_FDEV_SETUP_WRITE);

static void hardware_init(void) {
    DDRB|=_BV(DDB4); /* D12 test ISR */
#if PLANTA_MOTOR
    /* PWM original D9, phase correct 8 bit, 490.196 Hz. */
    DDRB|=_BV(DDB1)|_BV(DDB0); DDRD|=_BV(DDD7);
    PORTD|=_BV(PD7); PORTB&=(uint8_t)~_BV(PB0);
    TCCR1A=_BV(WGM10); TCCR1B=_BV(CS11)|_BV(CS10); OCR1A=0;
    /* Timer0: reloj de 4 us. Timer2: 1 ms, control cada 20 ticks. */
    TCCR0A=0; TCCR0B=_BV(CS01)|_BV(CS00); TIMSK0=_BV(TOIE0);
    TCCR2A=_BV(WGM21); TCCR2B=_BV(CS22); OCR2A=249; TIMSK2=_BV(OCIE2A);
    DDRD&=(uint8_t)~_BV(DDD2); PORTD|=_BV(PD2);
    EICRA=_BV(ISC01)|_BV(ISC00); EIFR=_BV(INTF0); EIMSK=_BV(INT0);
    UCSR0A=_BV(U2X0); UBRR0=(F_CPU/(8UL*UART_BAUD))-1;
#else
    DDRD|=_BV(DDD5); PORTD&=(uint8_t)~_BV(PD5);
    TCCR0A=_BV(WGM01)|_BV(WGM00); TCCR0B=_BV(CS01)|_BV(CS00); OCR0B=0;
    TCCR1A=0; TCCR1B=_BV(WGM12)|_BV(CS12); OCR1A=62499; TIMSK1=_BV(OCIE1A);
    TCCR2A=0; TCCR2B=_BV(CS22); TIMSK2=_BV(TOIE2);
    DDRC&=(uint8_t)~_BV(DDC0); PORTC&=(uint8_t)~_BV(PC0);
    DIDR0=_BV(ADC0D); ADMUX=_BV(REFS0); ADCSRB=0;
    ADCSRA=_BV(ADEN)|_BV(ADPS2)|_BV(ADPS1)|_BV(ADPS0);
    UCSR0A=0; UBRR0=(F_CPU/(16UL*UART_BAUD))-1;
#endif
    UCSR0C=_BV(UCSZ01)|_BV(UCSZ00);
    UCSR0B=_BV(RXEN0)|_BV(TXEN0)|_BV(RXCIE0);
    stdout=&serial_output;
    (void)actuator(0.0f);
}

static void fixed(float x,uint8_t digits) {
    long scale=digits==5 ? 100000L : 1000L;
    long value=(long)(fabsf(x)*(float)scale+0.5f);
    if(x<0.0f) putchar('-');
    if(digits==5) printf_P(PSTR("%ld.%05ld"),value/scale,value%scale);
    else printf_P(PSTR("%ld.%03ld"),value/scale,value%scale);
}
static void output_sample(const Sample *s) {
    printf_P(PSTR("%lu.%03lu,%u,%s,%u,"),s->ms/1000UL,s->ms%1000UL,
        s->phase,s->hybrid ? "HYB" : "PID",s->segment);
    fixed(s->ref,3); putchar(','); fixed(s->y,3); putchar(',');
    fixed(s->u,3); putchar(','); fixed(s->error,3); putchar(',');
    fixed(s->kp,5); putchar(','); fixed(s->ki,5); putchar(','); fixed(s->kd,5);
    printf_P(PSTR(",%lu,%u,%u\r\n"),s->exec_us,s->missed,s->dropped);
}
static void stop_now(void) {
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { stop_requested=1; command.kind=CMD_NONE; (void)actuator(0.0f); }
}
static void help(void) {
    printf_P(PSTR("#READY " PLANT_NAME " Ts_ms=%lu baud=%lu UMAX="),SAMPLE_MS,UART_BAUD);
    fixed(UMAX,3);
    printf_P(PSTR("\r\n# START PID|HYB referencia duracion_s; REF referencia; STOP; PING; ?\r\n"));
    printf_P(PSTR("# phase:0=baseline,1=control,2=fin; u: motor PWM0..255, termica %%\r\n"));
    printf_P(PSTR("t_s,phase,mode,segment,ref,y,u,error,kp,ki,kd,control_us,missed,tx_dropped\r\n"));
}
static void parse(char *line) {
    char *cmd=strtok(line," "),*mode,*rs,*ds,*end;
    float r; unsigned long seconds;
    if(!cmd) return;
    if(!strcmp(cmd,"PING")) { uint32_t now=clock_us(); ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {last_ping_us=now;} return; }
    if(!strcmp(cmd,"STOP")) { stop_now(); printf_P(PSTR("#STOP\r\n")); return; }
    if(!strcmp(cmd,"?")) { help(); return; }
    if(!strcmp(cmd,"START")) {
        mode=strtok(NULL," "); rs=strtok(NULL," "); ds=strtok(NULL," ");
        if(!mode||!rs||!ds||strtok(NULL," ")) goto bad;
        if(strcmp(mode,"PID") && strcmp(mode,"HYB")) goto bad;
        r=(float)strtod(rs,&end); if(*end||!isfinite(r)||r<0||r>REF_MAX) goto bad;
        seconds=strtoul(ds,&end,10); if(*end||!seconds||seconds>MAX_DURATION_S) goto bad;
        if(run_active || command.kind!=CMD_NONE || qhead!=qtail || end_notice) goto bad;
        uint32_t now=clock_us();
        ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
            command.ref=r; command.duration=seconds*1000UL;
            command.hybrid=!strcmp(mode,"HYB"); last_ping_us=now; command.kind=CMD_START;
        }
        printf_P(PSTR("#ACCEPTED START\r\n")); return;
    }
    if(!strcmp(cmd,"REF")) {
        rs=strtok(NULL," "); if(!rs||strtok(NULL," ")) goto bad;
        r=(float)strtod(rs,&end); if(*end||!isfinite(r)||r<0||r>REF_MAX) goto bad;
        if(!run_active || command.kind!=CMD_NONE) goto bad;
        ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { command.ref=r; command.kind=CMD_REF; }
        printf_P(PSTR("#ACCEPTED REF\r\n")); return;
    }
bad: printf_P(PSTR("#ERROR comando invalido, fuera de rango o prueba activa\r\n"));
}

int main(void) {
    char line[64]; uint8_t length=0,discard=0;
    cli(); hardware_init(); sei(); help();
    for(;;) {
        if(rx_error) {
            ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { rx_error=0; rx_tail=rx_head; }
            stop_now(); length=0; discard=1;
            printf_P(PSTR("#ERROR UART; salida apagada\r\n"));
        }
        while(rx_tail!=rx_head) {
            char b=rx[rx_tail]; rx_tail=(rx_tail+1U)%RX_SIZE;
            if(b=='\r'||b=='\n') {
                if(!discard && length) { line[length]=0; parse(line); }
                length=0; discard=0;
            } else if(!discard) {
                if(length<sizeof(line)-1) line[length++]=b;
                else { discard=1; stop_now(); printf_P(PSTR("#ERROR linea larga\r\n")); }
            }
        }
        if(qhead!=qtail) {
            Sample s;
            ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { s=queue[qtail]; qtail=(qtail+1U)%QUEUE_SIZE; }
            output_sample(&s);
        }
        if(end_notice && qhead==qtail) {
            uint8_t code;
            ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { code=end_notice; end_notice=0; }
            /* 1:plazo, 2:temperatura, 3:enlace, 4:STOP, 5:duracion normal. */
            printf_P(PSTR("#FIN %u\r\n"),code);
        }
    }
}

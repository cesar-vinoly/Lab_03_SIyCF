"""Genera un solo archivo C por planta a partir del firmware modular validado."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    config = (ROOT / 'firmware/config.h').read_text(encoding='utf-8')
    header = (ROOT / 'firmware/control.h').read_text(encoding='utf-8')
    control = (ROOT / 'firmware/control.c').read_text(encoding='utf-8')
    hardware = (ROOT / 'firmware/main.c').read_text(encoding='utf-8')
    control = control.replace('#include "control.h"\n', '')
    hardware = hardware.replace('#include "config.h"\n', '').replace('#include "control.h"\n', '')
    for plant, flag, name, pins in [
        ('motor', 1, 'main_motor.c', 'ENA D9; IN1 D7; IN2 D8; encoder D2; UART 115200; Ts 20 ms'),
        ('termica', 0, 'main_planta_termica.c', 'LM35 A0; calefactor D5; UART 9600; Ts 1 s'),
    ]:
        preamble = f'''/* {name} -- ATmega328P, 16 MHz, C AVR-GCC, sin framework Arduino.
 * Archivo independiente: contiene configuracion, PID, TSK-1 y hardware.
 * {pins}.
 * Modo PID: ganancias fijas. Modo HYB: ganancias ajustadas por TSK-1.
 * La planta termica conserva Kd=0 (PI). No arranca hasta recibir START.
 * Usar capturar_{plant}.py para iniciar y registrar el ensayo.
 * Editar ESTE archivo si se utiliza solo; no necesita otros .c/.h del proyecto.
 * Si se edita firmware/, regenerar con generar_main_independientes.py.
 */
#ifndef F_CPU
#define F_CPU 16000000UL
#endif
#define PLANTA_MOTOR {flag}

'''
        text = preamble + config + '\n' + header + '\n' + control + '\n' + hardware
        (ROOT / name).write_text(text, encoding='utf-8', newline='\n')
        print(f'Generado: {name}')


if __name__ == '__main__':
    main()

"""Compara CSV con el mismo horizonte, referencia y periodo de muestreo."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np

REQUIRED = set('t_s,phase,mode,segment,ref,y,u,error,kp,ki,kd,control_us,missed,tx_dropped'.split(','))


def load_csv(path, plant=None):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError(f'CSV vacio: {path}')
    if not REQUIRED.issubset(rows[0]):
        raise ValueError(f'Faltan columnas: {sorted(REQUIRED-set(rows[0]))}')
    if any(None in r or any(v is None or v == '' for v in r.values()) for r in rows):
        raise ValueError('Fila incompleta o con columnas adicionales.')
    data = {k: np.array([r[k] for r in rows], dtype=str if k == 'mode' else float) for k in REQUIRED}
    for k, values in data.items():
        if k != 'mode' and not np.all(np.isfinite(values)):
            raise ValueError(f'Datos no finitos en {k}: {path}')
    if len(set(data['mode'])) != 1 or data['mode'][0] not in ('PID', 'HYB'):
        raise ValueError('Se requiere un solo modo: PID o HYB.')
    if not np.allclose(data['error'], data['ref']-data['y'], rtol=0, atol=0.0021):
        raise ValueError('La columna error no coincide con ref-y.')
    for key in ('phase', 'segment', 'control_us', 'missed', 'tx_dropped'):
        if np.any(data[key] < 0) or np.any(data[key] != np.floor(data[key])):
            raise ValueError(f'Campo entero invalido: {key}')
    if np.any(data['missed']) or np.any(data['tx_dropped']):
        raise ValueError('CSV con plazos incumplidos o muestras perdidas.')
    active = np.flatnonzero(data['phase'] == 1)
    if len(active) < 1 or data['phase'][-1] != 2:
        raise ValueError('Faltan el tramo de control o la muestra de cierre.')
    first = active[0]
    if not (np.all(data['phase'][:first] == 0) and np.all(data['phase'][first:-1] == 1)):
        raise ValueError('Fases invalidas: reposo, control y un unico cierre.')
    dt = np.diff(data['t_s'])
    if data['t_s'][0] < 0 or np.any(dt <= 0) or not np.allclose(dt, np.median(dt), rtol=0, atol=1e-5):
        raise ValueError('Muestreo irregular o tiempo repetido; no se inventan muestras.')
    if plant is not None and not np.allclose(dt, 0.02 if plant == 'motor' else 1.0, rtol=0, atol=1e-5):
        raise ValueError('El periodo de muestreo no corresponde a la planta seleccionada.')
    for k in data:
        data[k] = data[k][first:]
    data['t_s'] = data['t_s'] - data['t_s'][0]
    meta = Path(path).with_suffix('.json')
    if meta.exists():
        info = json.loads(meta.read_text(encoding='utf-8'))
        if info.get('estado') not in (None, 'completo'):
            raise ValueError('Captura incompleta segun los metadatos.')
        if info.get('codigo_fin') not in (None, 5):
            raise ValueError('El ensayo no finalizo por duracion normal.')
        if plant is not None and info.get('planta', plant) != plant:
            raise ValueError('Los metadatos corresponden a otra planta.')
        if info.get('modo', data['mode'][0]) != data['mode'][0]:
            raise ValueError('El modo no coincide con los metadatos.')
        if 'duracion_s' in info and not np.isclose(data['t_s'][-1], info['duracion_s'], rtol=0, atol=1e-5):
            raise ValueError('El horizonte no coincide con la duracion solicitada.')
        if 'filas' in info and info['filas'] != len(rows):
            raise ValueError('La cantidad de muestras no coincide con los metadatos.')
    return data


def cumulative_errors(d):
    """Trapecios desde el inicio del control; primera integral acumulada igual a cero."""
    t = np.asarray(d['t_s'], dtype=float)
    t = t - t[0]
    e = np.asarray(d['ref'], dtype=float) - np.asarray(d['y'], dtype=float)
    if len(t) < 2 or np.any(np.diff(t) <= 0):
        raise ValueError('Se requieren al menos dos tiempos estrictamente crecientes.')
    result = dict(t_s=t, ref=d['ref'], y=d['y'], error=e, error_absoluto=np.abs(e),
                  error_cuadrado=e**2, t_error_absoluto=t*np.abs(e))
    for key, values in [('IAE_acumulado', np.abs(e)), ('ISE_acumulado', e**2),
                        ('ITAE_acumulado', t*np.abs(e))]:
        result[key] = np.r_[0.0, np.cumsum(np.diff(t)*(values[:-1]+values[1:])/2)]
    return result


def metrics(d, hold_s=1.0, band_fraction=0.02):
    t,y,r,u = (d[k] for k in ['t_s','y','ref','u'])
    error = r-y
    accumulated = cumulative_errors(d)
    result = {'horizonte_s':float(t[-1]-t[0]), 'Ts_s':float(np.median(np.diff(t))),
              'IAE':float(accumulated['IAE_acumulado'][-1]),
              'ISE':float(accumulated['ISE_acumulado'][-1]),
              'ITAE':float(accumulated['ITAE_acumulado'][-1]),
              'esfuerzo_integral_u2':float(np.sum(u[:-1]**2*np.diff(t))),
              'variacion_total_u':float(np.sum(abs(np.diff(u[:-1])))),
              'Ju':float(np.sum(np.diff(u[:-1])**2)),
              'control_us_max':float(np.max(d['control_us']))}
    result.update(sobreimpulso_pct=None, establecimiento_s=None, subida_10_90_s=None,
                  error_final_medio=None, banda_absoluta=None)
    if np.allclose(r, r[0], rtol=0, atol=1e-6):
        step = r[0]-y[0]
        tail = max(1, int(np.ceil(len(y)*0.1)))
        result['error_final_medio'] = float(np.mean(error[-tail:]))
        if abs(step) > 1e-9:
            progress = (y-y[0])/step
            result['sobreimpulso_pct'] = float(max(0, np.max(progress)-1)*100)
            band = band_fraction*abs(step)
            result['banda_absoluta'] = float(band)
            outside = np.flatnonzero(abs(error)>band)
            index = int(outside[-1]+1) if len(outside) else 0
            if index < len(t) and t[-1]-t[index] >= hold_s:
                result['establecimiento_s'] = float(t[index]-t[0])
            ten, ninety = np.flatnonzero(progress>=0.1), np.flatnonzero(progress>=0.9)
            if len(ten) and len(ninety):
                result['subida_10_90_s'] = float(t[ninety[0]]-t[ten[0]])
    return result

def integral_units(plant):
    unit = 'rpm' if plant == 'motor' else 'C'
    return dict(IAE=f'{unit}*s', ISE=f'{unit}^2*s', ITAE=f'{unit}*s^2')


def save_error_series(d, path):
    result = cumulative_errors(d)
    with Path(path).open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(result)
        writer.writerows(zip(*result.values()))


def single_output_paths(path):
    path = Path(path)
    return [path.with_name(path.stem + suffix) for suffix in
            ('_errores.csv', '_metricas.csv', '_metricas.json')]


def export_single(path, plant):
    d = load_csv(path, plant)
    result = metrics(d, 1 if plant == 'motor' else 30)
    errors, summary, details = single_output_paths(path)
    units = integral_units(plant)
    save_error_series(d, errors)
    with summary.open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['indicador', 'valor', 'unidad'])
        for key, value in result.items():
            writer.writerow([key, value, units.get(key, '')])
    details.write_text(json.dumps(dict(planta=plant, modo=str(d['mode'][0]),
        archivo_origen=str(Path(path)), unidades=units, metricas=result,
        integracion='Trapecios; tiempo cero al inicio del control; incluye extremo final.',
        nota='null = no alcanzado/no aplicable. Error final no demuestra estado estacionario.'),
        indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')
    return result


def improvement(classic, hybrid):
    """Positivo: menor indice hibrido; una base cero no tiene porcentaje."""
    return None if classic == 0 else 100.0*(classic-hybrid)/classic


def validate_pair(x, y, tolerance=0.5):
    if not np.isfinite(tolerance) or tolerance < 0:
        raise ValueError('La tolerancia inicial debe ser finita y no negativa.')
    if set(x['mode']) != {'PID'} or set(y['mode']) != {'HYB'}:
        raise ValueError('Indicar primero el CSV clasico y despues el hibrido.')
    if len(x['t_s']) != len(y['t_s']) or not np.allclose(x['t_s'], y['t_s'], rtol=0, atol=1e-5):
        raise ValueError('Los horizontes o periodos de muestreo son diferentes.')
    if not np.allclose(x['ref'], y['ref'], rtol=0, atol=1e-5):
        raise ValueError('Las referencias o instantes de cambio no coinciden.')
    if abs(x['y'][0]-y['y'][0]) > tolerance:
        raise ValueError('Condiciones iniciales diferentes: repetir desde un estado equivalente.')


def plot_comparison(first, second, out, plant, title=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10, 'axes.grid':True, 'grid.alpha':0.25})
    fig, axes = plt.subplots(3, 1, figsize=(10,8), sharex=True, constrained_layout=True)
    if title: fig.suptitle(title)
    for d, label, color in [(first,'Clasico','#2166ac'),(second,'Hibrido TSK-1','#c65322')]:
        t = d['t_s']
        axes[0].plot(t,d['y'],label=label,color=color)
        axes[1].step(t,d['u'],where='post',color=color,label=label)
        axes[2].plot(t,d['ref']-d['y'],color=color,label=label)
    axes[0].plot(first['t_s'],first['ref'],'--',color='#333333',label='Referencia')
    axes[0].set_ylabel('Velocidad [rpm]' if plant=='motor' else 'Temperatura [°C]')
    axes[1].set_ylabel('PWM [0–255]' if plant=='motor' else 'Potencia [%]')
    axes[2].set_ylabel('Error'); axes[2].set_xlabel('Tiempo desde inicio del control [s]')
    axes[0].legend(); fig.savefig(out/'comparacion.png',dpi=180); plt.close(fig)
    fig, axes = plt.subplots(3,1,figsize=(10,7),sharex=True,constrained_layout=True)
    if title: fig.suptitle(title)
    for ax, key in zip(axes,['kp','ki','kd']):
        ax.plot(first['t_s'],first[key],label='Clasico',color='#2166ac')
        ax.plot(second['t_s'],second[key],label='Hibrido',color='#c65322')
        ax.set_ylabel(key)
    axes[0].legend(); axes[-1].set_xlabel('Tiempo [s]')
    fig.savefig(out/'ganancias.png',dpi=180); plt.close(fig)

def plot_integrals(first, second, out, plant, title=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    units = integral_units(plant)
    pair = [cumulative_errors(first), cumulative_errors(second)]
    colors = ['#2166ac', '#c65322']
    labels = ['Clasico', 'Hibrido TSK-1']
    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True, constrained_layout=True)
    fig.suptitle(title or 'Indicadores integrales acumulados')
    for ax, key in zip(axes, ['IAE', 'ISE', 'ITAE']):
        for data, label, color in zip(pair, labels, colors):
            ax.plot(data['t_s'], data[key+'_acumulado'], label=label, color=color)
        ax.set_ylabel(f'{key} [{units[key]}]')
        ax.grid(alpha=0.25)
    axes[0].legend()
    axes[-1].set_xlabel('Tiempo desde inicio del control [s]')
    fig.savefig(out/'indicadores_integrales.png', dpi=180)
    plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(11, 4), constrained_layout=True)
    fig.suptitle(title or 'Indices al final del mismo intervalo')
    for ax, key in zip(axes, ['IAE', 'ISE', 'ITAE']):
        values = [float(data[key+'_acumulado'][-1]) for data in pair]
        bars = ax.bar(labels, values, color=colors)
        ax.bar_label(bars, labels=[f'{v:.5g}' for v in values], padding=3)
        ax.set_title(key)
        ax.set_ylabel(units[key])
        ax.set_ylim(0, max(values)*1.20 if max(values) else 1)
        ax.grid(axis='y', alpha=0.25)
    fig.savefig(out/'comparacion_indices.png', dpi=180)
    plt.close(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('clasico', type=Path)
    p.add_argument('hibrido', type=Path)
    p.add_argument('--planta', choices=['motor', 'termica'], required=True)
    p.add_argument('--salida', type=Path, default=Path('comparacion'))
    p.add_argument('--tolerancia-inicial', type=float, default=0.5)
    p.add_argument('--permanencia', type=float, default=None)
    a = p.parse_args()
    try:
        x, y = load_csv(a.clasico, a.planta), load_csv(a.hibrido, a.planta)
        validate_pair(x, y, a.tolerancia_inicial)
    except (ValueError, OSError) as exc:
        p.error(str(exc))
    hold = a.permanencia if a.permanencia is not None else (1 if a.planta == 'motor' else 30)
    if not np.isfinite(hold) or hold < 0:
        p.error('--permanencia debe ser finita y no negativa.')
    a.salida.mkdir(parents=True, exist_ok=True)
    mx, my = metrics(x, hold), metrics(y, hold)
    units = integral_units(a.planta)
    reductions = {k: improvement(mx[k], my[k]) for k in units}
    with (a.salida/'metricas.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['indicador', 'clasico', 'hibrido', 'unidad', 'reduccion_hibrido_pct'])
        for key in mx:
            w.writerow([key, mx[key], my[key], units.get(key, ''), reductions.get(key, '')])
    (a.salida/'metricas.json').write_text(json.dumps(dict(
        planta=a.planta, clasico=mx, hibrido=my, unidades=units,
        reduccion_hibrido_pct=reductions,
        archivos=dict(clasico=str(a.clasico), hibrido=str(a.hibrido)),
        nota='null = no alcanzado/no aplicable. Reduccion positiva: menor indice hibrido; base cero: null.',
        banda_porcentaje_escalon=2, permanencia_minima_s=hold),
        indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')
    save_error_series(x, a.salida/'errores_clasico.csv')
    save_error_series(y, a.salida/'errores_hibrido.csv')
    simulated = any('simulaciones' in path.parts for path in [a.clasico, a.hibrido])
    title = f'SIMULACION | {a.planta}' if simulated else None
    plot_comparison(x, y, a.salida, a.planta, title)
    plot_integrals(x, y, a.salida, a.planta, title)
    for key in units:
        reduction = reductions[key]
        text = 'no definida (base cero)' if reduction is None else f'{reduction:+.3f}%'
        print(f'{key}: clasico={mx[key]:.7g}; hibrido={my[key]:.7g} [{units[key]}]; reduccion={text}')
    print(f'Resultados: {a.salida.resolve()}')


if __name__ == '__main__':
    main()

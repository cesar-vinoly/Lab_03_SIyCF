"""Pruebas de protocolo sin abrir puertos fisicos, e indices con senales conocidas."""
import contextlib
import csv
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import numpy as np
import capturar
from metricas import load_csv, metrics, cumulative_errors, validate_pair, improvement, single_output_paths
from simular import verify

class FakeSerial:
    variant='normal'
    plant='motor'
    mode='PID'
    instances=[]
    def __init__(self,*args,**kwargs):
        self.lines=[];self.commands=[];self.instances.append(self)
    def reset_input_buffer(self):self.lines=[]
    def write(self,b):
        text=b.decode().strip();self.commands.append(text)
        if text=='?':
            plant=('termica' if self.plant=='motor' else 'motor') if self.variant=='planta_incorrecta' else self.plant
            sample,baud=(20,115200) if self.plant=='motor' else (1000,9600)
            self.lines=[f'#READY {plant} Ts_ms={sample} baud={baud}',','.join(capturar.FIELDS)]
        elif text.startswith('START '):
            self.lines=['#ACCEPTED START']
            _,mode,reference,duration=text.split()
            sample,baseline=(.02,2) if self.plant=='motor' else (1,20)
            count=round((baseline+int(duration))/sample)
            for k in range(count+1):
                if self.variant=='hueco' and k==round(baseline/sample)+1:continue
                t=round(k*sample,3);phase=0 if t<baseline else (1 if k<count else 2)
                ref=float(reference);measured=ref-2 # error constante: valores analiticos conocidos.
                row=[t,phase,mode,0,ref,measured,0,2,.8356,5.498,.03175,500,0,0]
                if self.variant=='error_corrupto':row[7]=999
                self.lines.append(','.join(map(str,row)))
            self.lines.append('#FIN 5')
    def readline(self):
        if not hasattr(self,'fragment'):self.fragment=b''
        if not self.fragment and self.lines:self.fragment=(self.lines.pop(0)+'\n').encode()
        if not self.fragment:return b''
        limit=7 if self.variant=='fragmentada' else len(self.fragment)
        result,self.fragment=self.fragment[:limit],self.fragment[limit:]
        return result
    def flush(self):pass
    def close(self):pass

def main():
    root=Path(__file__).resolve().parent
    # Los main independientes deben contener el mismo firmware modular, sin dependencias locales.
    config=(root/'firmware/config.h').read_text(encoding='utf-8')
    header=(root/'firmware/control.h').read_text(encoding='utf-8')
    control=(root/'firmware/control.c').read_text(encoding='utf-8').replace('#include "control.h"\n','')
    hardware=(root/'firmware/main.c').read_text(encoding='utf-8').replace('#include "config.h"\n','').replace('#include "control.h"\n','')
    expected=config+'\n'+header+'\n'+control+'\n'+hardware
    for file,flag in [('main_motor.c',1),('main_planta_termica.c',0)]:
        source=(root/file).read_text(encoding='utf-8')
        assert source.endswith(expected) and f'#define PLANTA_MOTOR {flag}\n' in source
        assert '#include "' not in source
    verify()
    old_serial=sys.modules.get('serial');old_sleep=capturar.time.sleep;old_argv=sys.argv
    sys.modules['serial']=types.SimpleNamespace(Serial=FakeSerial)
    capturar.time.sleep=lambda _:None
    try:
        test_root=Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory(prefix='lab_pid_test_',dir=test_root) as tmp:
            assert Path(tmp).resolve().is_relative_to(test_root)
            cases=[(plant,mode,variant) for plant in ['motor','termica'] for mode in ['PID','HYB']
                   for variant in ['normal','fragmentada','hueco','planta_incorrecta','error_corrupto']]
            for plant,mode,variant in cases:
                FakeSerial.variant=variant;FakeSerial.plant=plant
                out=Path(tmp)/(plant+'_'+mode+'_'+variant+'.csv')
                sys.argv=['capturar.py','--puerto','FAKE','--planta',plant,'--modo',mode,
                    '--referencia','45','--duracion','3','--salida',str(out)]
                failed=False
                with contextlib.redirect_stdout(io.StringIO()):
                    try:capturar.main()
                    except SystemExit:failed=True
                valid=variant in ('normal','fragmentada')
                assert failed != valid, (plant,mode,variant)
                meta=json.loads(out.with_suffix('.json').read_text())
                assert (meta['estado']=='completo')==valid
                assert 'STOP' in FakeSerial.instances[-1].commands
                if valid:
                    d=load_csv(out,plant)
                    assert len(d['t_s'])==(151 if plant=='motor' else 4) and np.isclose(d['t_s'][-1],3)
                    m=metrics(d)
                    assert np.allclose([m['IAE'],m['ISE'],m['ITAE']],[6,12,9])
                    errors,summary,details=single_output_paths(out)
                    assert all(path.exists() for path in (errors,summary,details))
                    reported=json.loads(details.read_text())['metricas']
                    assert reported['IAE']==m['IAE']
                else:
                    try:load_csv(out)
                    except ValueError:pass
                    else:raise AssertionError('Se acepto una captura incompleta.')
    finally:
        if old_serial is None:sys.modules.pop('serial',None)
        else:sys.modules['serial']=old_serial
        capturar.time.sleep=old_sleep;sys.argv=old_argv
    # ITAE debe usar tiempo relativo aunque el registro empiece en t=20 s.
    for error in [2,-2,0]:
        t=np.linspace(20,30,101)
        d=dict(t_s=t,ref=np.full_like(t,error),y=np.zeros_like(t),u=np.zeros_like(t),control_us=np.zeros_like(t))
        m=metrics(d);c=cumulative_errors(d)
        assert np.allclose([m['IAE'],m['ISE'],m['ITAE']],[10*abs(error),10*error**2,50*abs(error)])
        assert c['IAE_acumulado'][0]==0 and np.all(np.diff(c['ITAE_acumulado'])>=0)
    assert improvement(0,1) is None and improvement(10,8)==20 and improvement(10,12)==-20
    # Comparaciones invalidas: duracion, referencia, estado inicial o modos distintos.
    t=np.linspace(0,1,51)
    a=dict(t_s=t,ref=np.ones_like(t),y=np.zeros_like(t),mode=np.full(len(t),'PID'))
    b={k:v.copy() for k,v in a.items()};b['mode'][:]='HYB'
    validate_pair(a,b)
    for key,value in [('t_s',t*2),('ref',np.full_like(t,2)),('y',np.ones_like(t)),('mode',np.full(len(t),'PID'))]:
        invalid={k:v.copy() for k,v in b.items()};invalid[key]=value
        try:validate_pair(a,invalid)
        except ValueError:pass
        else:raise AssertionError('Se acepto una comparacion invalida: '+key)
    print('OK: PID/TSK, integrales, 20 capturas de motor/termica PID/HYB, lineas fragmentadas, rechazos y STOP.')

if __name__=='__main__':main()

"""Simulacion ideal de las funciones de transferencia; no son ensayos fisicos."""
import ast
import csv
import json
from pathlib import Path
import re
import numpy as np
from scipy.signal import tf2ss, cont2discrete
from metricas import metrics, plot_comparison
from capturar import FIELDS

ROOT=Path(__file__).resolve().parent

def number(expr):
    expr=re.sub(r'(?<=\d)(?:UL|U|f)\b','',expr)
    def visit(n):
        if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return n.value
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -visit(n.operand)
        if isinstance(n,ast.BinOp):
            a,b=visit(n.left),visit(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
        raise ValueError(f'Expresion no numerica: {expr}')
    return float(visit(ast.parse(expr,mode='eval').body))

def parameters(plant):
    text=(ROOT/'firmware/config.h').read_text(encoding='utf-8')
    motor,thermal=text.split('#if PLANTA_MOTOR\n',1)[1].split('#else',1)
    part=motor if plant=='motor' else thermal.split('#endif',1)[0]
    raw=dict(re.findall(r'^#define\s+(\w+)\s+(.+)$',part,re.M))
    keys=['SAMPLE_MS','KP0','KI0','KD0','UMAX','EMAX','DEMAX','DELTA_ALPHA','GAIN_BETA']
    return {k:number(raw[k]) for k in keys}

def membership(x,n):
    mu=np.zeros(n);x=float(np.clip(x,-1,1))
    if x<=-1:mu[0]=1
    elif x>=1:mu[-1]=1
    else:
        pos=(x+1)*(n-1)*0.5;i=int(pos)
        mu[i+1]=pos-i;mu[i]=1-mu[i+1]
    return mu

def fuzzy(en,den):
    en,den=np.clip([en,den],-1,1)
    me,md=membership(en,5),membership(den,3)
    out=np.zeros(3);total=0.0
    for i in range(5):
        se=np.sign(i-2)
        for j in range(3):
            sd=np.sign(j-1);w=me[i]*md[j]
            out+=w*np.array([.12*se*en+.06*se*den,-.12*se*en-.04*sd*den+.02,.08*sd*den])
            total+=w
    return out/total if total>1e-6 else np.zeros(3)

class Controller:
    def __init__(self,p,hybrid,error):
        self.p=p;self.hybrid=hybrid;self.previous=error;self.delta=0.0;self.integral=0.0
        self.base=np.array([p['KP0'],p['KI0'],p['KD0']]);self.gains=self.base.copy()
    def step(self,r,y):
        p=self.p;ts=p['SAMPLE_MS']/1000;error=r-y
        self.delta+=p['DELTA_ALPHA']*(error-self.previous-self.delta);self.previous=error
        if self.hybrid:
            change=fuzzy(error/p['EMAX'],self.delta/p['DEMAX'])
            target=np.clip(self.base*(1+change),self.base*[.85,.80,.90],self.base*[1.20,1.10,1.15])
            self.gains+=p['GAIN_BETA']*(target-self.gains)
        kp,ki,kd=self.gains;limit=p['UMAX']/(.8*p['KI0'])
        trial=float(np.clip(self.integral+ts*error,-limit,limit))
        v=kp*error+ki*trial+kd*self.delta/ts
        if not ((v>p['UMAX'] and error>0) or (v<0 and error<0)):self.integral=trial
        return float(np.clip(kp*error+ki*self.integral+kd*self.delta/ts,0,p['UMAX']))

def simulate(plant,hybrid,reference=None,duration=None,initial=None,scenario='escalon'):
    p=parameters(plant);ts=p['SAMPLE_MS']/1000
    if plant=='motor':
        num,den=[-46.66,559.1],[1,12.68,216.9,884]
        r0=80 if reference is None else reference;duration=30 if duration is None else duration
        offset=0 if initial is None else initial
    else:
        num,den=[.008593,.0002336],[1,.0338,.0001793]
        r0=45 if reference is None else reference;duration=600 if duration is None else duration
        offset=28.4825 if initial is None else initial
    A,B,C,D,ts=cont2discrete((*tf2ss(num,den),),ts)
    x=np.zeros(A.shape[0]);ctrl=Controller(p,hybrid,r0-offset)
    rows=[];max_delta=0
    for k in range(round(duration/ts)+1):
        t=k*ts;r=r0;segment=0
        if scenario=='cambios' and t>=duration/3:r=r0+(20 if plant=='motor' else 5);segment=1
        if scenario=='cambios' and t>=2*duration/3:r=r0;segment=2
        y=float((C@x).item())+offset
        # Perturbacion aditiva a la entrada del modelo, solo en simulacion.
        disturbance=(-20 if plant=='motor' else -5) if scenario=='perturbacion' and duration*.5<=t<duration*.7 else 0
        end=k==round(duration/ts)
        u=0 if end else ctrl.step(r,y)
        if plant=='motor':u=float(np.floor(u+.5))
        else:u=min(np.floor(u*2.56+.5),np.floor(p['UMAX']*2.56))/2.56
        max_delta=max(max_delta,abs(ctrl.delta))
        row=[t,2 if end else 1,'HYB' if hybrid else 'PID',segment,r,y,u,r-y,*ctrl.gains,0,0,0]
        rows.append(row)
        if not end:x=A@x+B[:,0]*(u+disturbance)
    data={key:np.array([row[i] for row in rows],dtype=str if key=='mode' else float) for i,key in enumerate(FIELDS)}
    return data,rows,max_delta

def verify():
    # Cobertura de extremos y cruces; ganancias y saturacion en el dominio completo.
    for x in np.linspace(-1.2,1.2,101):
        for n in [3,5]:
            m=membership(x,n)
            assert np.all(m>=0) and abs(sum(m)-1)<1e-12
        for d in np.linspace(-1.2,1.2,31):
            f=fuzzy(x,d)
            assert np.all(np.isfinite(f)) and -.061<=f[0]<=.181 and -.141<=f[1]<=.021 and 0<=f[2]<=.081
    for plant in ['motor','termica']:
        p=parameters(plant)
        for hybrid in [False,True]:
            c=Controller(p,hybrid,0)
            for r,y in [(10000,0)]*500+[(0,100)]*500+[(0,0)]*500:
                u=c.step(r,y)
                assert np.isfinite(u) and 0<=u<=p['UMAX']
                assert np.all(c.gains>=c.base*[.85,.8,.9]) and np.all(c.gains<=c.base*[1.2,1.1,1.15])
                assert abs(c.integral)<=p['UMAX']/(.8*p['KI0'])+1e-6
                if not hybrid:assert np.array_equal(c.gains,c.base)
    # Verificacion independiente de integrales: error=2, horizonte=10.
    t=np.linspace(0,10,101);d={'t_s':t,'ref':np.full_like(t,2),'y':np.zeros_like(t),
        'u':np.ones_like(t),'control_us':np.zeros_like(t)}
    m=metrics(d)
    assert np.isclose(m['IAE'],20) and np.isclose(m['ISE'],40) and np.isclose(m['ITAE'],100)
    assert m['establecimiento_s'] is None and m['subida_10_90_s'] is None
    assert np.isclose(m['esfuerzo_integral_u2'],10) and m['Ju']==0

def main():
    verify();out=ROOT/'simulaciones';out.mkdir(exist_ok=True)
    summary=[]
    for plant in ['motor','termica']:
        for scenario in ['escalon','cambios','perturbacion']:
            folder=out/f'{plant}_{scenario}';folder.mkdir(exist_ok=True)
            pair=[]
            for hybrid in [False,True]:
                data,rows,delta=simulate(plant,hybrid,scenario=scenario)
                mode='HYB' if hybrid else 'PID'
                with (folder/f'{mode}.csv').open('w',newline='',encoding='utf-8') as f:
                    w=csv.writer(f);w.writerow(FIELDS);w.writerows(rows)
                assert np.all(np.isfinite(data['y'])) and max(abs(data['y']))<200
                m=metrics(data,1 if plant=='motor' else 30)
                summary.append(dict(planta=plant,escenario=scenario,modo=mode,max_delta_filtrada=delta,**m))
                pair.append(data)
            plot_comparison(*pair,folder,plant,title=f'SIMULACION | {plant} | {scenario}')
    (out/'resultados.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    with (out/'resultados.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=summary[0]);w.writeheader();w.writerows(summary)
    for row in summary:
        print(row['planta'],row['escenario'],row['modo'],'IAE=',round(row['IAE'],4),'Mp=',row['sobreimpulso_pct'],'max_de=',round(row['max_delta_filtrada'],4))
    print('Pruebas numericas completadas. Resultados SIMULADOS, no experimentales.')

if __name__=='__main__':main()

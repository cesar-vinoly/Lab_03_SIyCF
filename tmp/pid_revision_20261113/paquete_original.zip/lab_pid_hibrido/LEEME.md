# Laboratorio: PID clasico e hibrido TSK-1

Implementacion inicial para ATmega328P a 16 MHz, en C con AVR-GCC, sin Arduino.
Conserva las conexiones y escalas de los dos programas de adquisicion proporcionados.
Incluye firmware, captura, comparacion y simulacion. Los ensayos fisicos y sus conclusiones
quedan pendientes; los resultados incluidos estan rotulados como SIMULACION.

## Archivos

- `firmware/main.c`: sensores, PWM, temporizadores, UART y lazo en interrupcion.
- `firmware/control.c` y `control.h`: PID, anti-windup y supervisor TSK-1.
- `firmware/config.h`: ganancias nominales, escalas, limites y tiempos.
- `platformio.ini`: proyectos `motor` y `termica`, sin framework Arduino.
- `compilar.ps1`: compilacion directa con AVR-GCC instalado por PlatformIO.
- `build/motor.hex` y `build/termica.hex`: versiones compiladas.
- `capturar.py`: adquisicion experimental a CSV, con metadatos y registro de incidencias.
- `metricas.py`: comparacion, indices y graficas.
- `simular.py`: simulaciones de las funciones de transferencia y verificaciones numericas.
- `reglas_tsk1.csv`: los 15 consecuentes afines, en forma de coeficientes.
- `simulaciones/`: respuestas teoricas y tabla de resultados. No son datos medidos.

## Conexiones conservadas

| Funcion | Motor | Planta termica |
|---|---|---|
| Actuacion | ENA=D9 | Calefactor H1=D5 |
| Direccion | IN1=D7, IN2=D8 | No aplica |
| Sensor | Encoder D2, flanco ascendente | LM35 A0, AVcc nominal 5 V |
| Lectura | 63.9 pulsos/vuelta, periodo entre flancos | Promedio de 16 conversiones ADC |
| PWM | Phase correct, 490.196 Hz | Fast PWM, 976.5625 Hz |
| Control | Cada 20 ms | Cada 1 s |
| UART | 115200, 8N1 | 9600, 8N1 |
| Unidad de u | PWM de 0 a 255 | Porcentaje de potencia |

D12 es una salida de diagnostico: permanece alta durante el calculo del lazo.
No conectar D12 al actuador. El encoder mantiene el pull-up externo de 4.7 kohm
y el pull-up interno de apoyo, como en el codigo original.

Los pines son etiquetas del Arduino Uno; el programa accede directamente a registros AVR.
Verificar la tension real de AVcc y ajustar `ADC_REFERENCE_MV` si corresponde. Se conserva
el divisor ADC de 1024 y la sensibilidad del LM35 de 10 mV/C.

## Compilar y cargar

Abrir esta carpeta como proyecto de PlatformIO. Elegir el entorno correspondiente antes
de compilar o cargar. Cerrar el monitor serie antes de ejecutar la captura.

```powershell
pio run -e motor
pio run -e motor -t upload --upload-port COM7

pio run -e termica
pio run -e termica -t upload --upload-port COM10
```

COM7 y COM10 son ejemplos: usar el puerto de la placa conectada. Tambien se puede
usar Upload desde Project Tasks en VS Code. No cargar ambos firmwares en la misma placa
sin cambiar el montaje correspondiente.

Para compilar directamente, sin cargar la placa:

```powershell
.\compilar.ps1
```

El script busca AVR-GCC en el directorio habitual de PlatformIO. Admite `-AvrBin RUTA`
si el compilador esta en otra ubicacion. Genera ELF y HEX para ambas plantas.

## Ejecutar los ensayos

Instalar dependencias una vez:

```powershell
& "C:\Python314\python.exe" -m pip install -r requirements.txt
```

Motor, referencia de 80 rpm y 30 segundos de control, precedidos por 2 segundos a PWM=0:

```powershell
& "C:\Python314\python.exe" capturar.py --puerto COM7 --planta motor --modo PID --referencia 80 --duracion 30 --salida datos/motor_pid.csv
& "C:\Python314\python.exe" capturar.py --puerto COM7 --planta motor --modo HYB --referencia 80 --duracion 30 --salida datos/motor_hibrido.csv
```

Realizar las dos pruebas con el motor detenido al inicio y la misma carga/alimentacion.

Planta termica, referencia de 45 C y 600 segundos de control, precedidos por 20 segundos
con el calefactor apagado:

```powershell
& "C:\Python314\python.exe" capturar.py --puerto COM10 --planta termica --modo PID --referencia 45 --duracion 600 --salida datos/termica_pi.csv
& "C:\Python314\python.exe" capturar.py --puerto COM10 --planta termica --modo HYB --referencia 45 --duracion 600 --salida datos/termica_hibrido.csv
```

Dejar volver la planta a la misma temperatura inicial antes del segundo ensayo. Los 20 s
de reposo inicial NO garantizan enfriamiento ni equilibrio termico. Conservar tambien las
condiciones ambientales y la posicion de sensores/ventiladores. El identificador de modo
`PID` es generico; en la planta termica el controlador efectivo es PI porque Kd=0.

Se pueden pedir cambios de referencia, medidos desde el inicio del control:

```powershell
& "C:\Python314\python.exe" capturar.py --puerto COM7 --planta motor --modo HYB --referencia 60 --duracion 40 --cambio 10:90 --cambio 25:60 --salida datos/motor_cambios_hyb.csv
```

Repetir la misma secuencia en modo PID. El comando se aplica al siguiente instante de
control despues de recibirlo; los CSV registran la referencia realmente aplicada. El
comparador rechaza secuencias que no coinciden muestra a muestra. Para perturbaciones
fisicas, reproducir carga, magnitud, duracion e instante y anotarlos en el registro del ensayo.

El programa no sobrescribe archivos de captura existentes. Ctrl+C envia STOP. Un reinicio,
error de recepcion, hueco de muestreo o final prematuro deja la captura como incompleta.

## Comparar

```powershell
& "C:\Python314\python.exe" metricas.py datos/motor_pid.csv datos/motor_hibrido.csv --planta motor --salida comparacion_motor
& "C:\Python314\python.exe" metricas.py datos/termica_pi.csv datos/termica_hibrido.csv --planta termica --salida comparacion_termica
```

Se comprueban modo, tiempo creciente, ausencia de muestras perdidas, referencia, horizonte,
muestreo y diferencia de medicion inicial menor o igual a 0.5 unidades. Esta tolerancia se
ajusta con `--tolerancia-inicial`, justificandola; no comprueba por si sola la equivalencia
de los estados internos o de las perturbaciones.

El comparador genera `metricas.csv`, `metricas.json`, `comparacion.png` y `ganancias.png`.
Calcula IAE, ISE e ITAE por trapecios sobre tiempo desde el inicio del control; excluye el
reposo y conserva la muestra final como extremo de integracion. El esfuerzo es integral
de u^2 con retencion de orden cero; variacion total y Ju se calculan con las actuaciones del
tramo activo, excluyendo el apagado posterior al ensayo.

Para referencia constante: sobreimpulso respecto de la amplitud r-y(0), subida de 10 a 90 %,
establecimiento en banda de +/-2 % de esa amplitud, y error medio del ultimo 10 % del registro.
Se exige permanencia final minima de 1 s en motor y 30 s en termica (`--permanencia`).
`null` o una celda vacia significa no alcanzado/no aplicable; no se inventa un tiempo de
establecimiento. El error final medio NO demuestra que se haya alcanzado un estado estacionario.
Con referencias variables se calculan indices globales; las medidas temporales de escalon
quedan sin valor y deben evaluarse con ensayos de referencia constante o ventanas definidas.

## Controlador implementado

| Parametro | Motor | Termica |
|---|---:|---:|
| Kp0 | 0.8356 | 1.286 |
| Ki0 | 5.498 | 0.01565 |
| Kd0 | 0.03175 | 0 |
| Ts [s] | 0.02 | 1 |
| Emax | 120 rpm | 40 C |
| DeltaEmax | 15 rpm/muestra | 0.5 C/muestra |
| Filtro de Delta e: tau [s] | 0.04 | 4 |
| Suavizado de ganancias: tau [s] | 0.10 | 5 |
| Actuacion maxima | 255 | 45 % nominal |

La actuacion termica se limita inicialmente al nivel ensayado. Por cuantizacion se aplica
como maximo 44.921875 %. Para ampliar el rango, modificar UMAX y justificarlo mediante
validacion. La salida del motor se redondea al entero PWM mas cercano.

El PID usa e=r-y, Delta e=e[k]-e[k-1], filtrado exponencial con alpha=Ts/(tau+Ts),
derivada D=Delta e_filtrada/Ts, e integral con clamp e integracion condicional contra windup.
Ambos modos usan exactamente el mismo filtro, discretizacion y limites. Al comenzar el
control se inicializa el error anterior al error actual, evitando un pulso derivativo de
arranque. Los cambios posteriores de referencia si pasan por el filtro de Delta e.

No se dispone del filtro derivativo Tf exportado por PID Tuner: el filtro de 0.04 s del motor
es una decision de implementacion documentada y simulada. La discretizacion no reproduce
necesariamente la respuesta exacta del objeto de MATLAB. Las ganancias de la imagen se
interpretan en forma paralela Kp, Ki y Kd, con tiempo en segundos y las escalas anteriores.

El Emax del motor corresponde al maximo escalon previsto 0->120 rpm; el de temperatura a
un escalon de hasta 40 C (por ejemplo 20->60 C). Los DeltaEmax se fijaron con margen sobre
la variacion filtrada maxima del modelo nominal: aproximadamente 12.045 rpm/muestra y
0.347 C/muestra, respectivamente. No son calibraciones experimentales. Verificar estos
rangos con el PID real; los cambios grandes de referencia pueden saturar la normalizacion.

### Supervisor TSK-1

Entradas: en=sat(e/Emax,-1,1), den=sat(Delta e_filtrada/DeltaEmax,-1,1).
No confundir Delta e con de/dt: tienen unidades y factores de normalizacion diferentes.

Conjuntos triangulares Ruspini con hombros en los extremos. Centros del error:
NG=-1, NP=-0.5, ZE=0, PP=0.5, PG=1. Centros de la variacion: N=-1, ZE=0, P=1.
Se evalua producto de pertenencias y promedio ponderado. Hay 15 reglas y como maximo
4 activas por punto. La suma de pesos vale 1; existe respaldo nominal ante suma nula.

Para cada regla (i,j), se=signo(centro del error), sd=signo(centro de la variacion):

```
fp =  0.12 se en + 0.06 se den
fi = -0.12 se en - 0.04 sd den + 0.02
fd =                 0.08 sd den
DeltaKq = Kq0 * promedio_ponderado(fq)
Kq_objetivo = sat(Kq0 + DeltaKq, Kq_min, Kq_max)
Kq[k] = Kq[k-1] + beta * (Kq_objetivo - Kq[k-1])
```

Son consecuentes afines TSK-1. La base es heuristica: refuerzo proporcional moderado con
error grande o que empeora, reduccion integral lejos de referencia/cambios rapidos y un
pequeno refuerzo derivativo durante cambios. La columna `reglas_tsk1.csv` contiene todos
los coeficientes; las correcciones relativas se convierten a unidades de ganancia con Kq0.

Limites: Kp entre 0.85 y 1.20 veces Kp0; Ki entre 0.80 y 1.10 veces Ki0; Kd entre 0.90 y
1.15 veces Kd0. Kp y Ki son estrictamente positivos. En termica Kd permanece en cero:
se compara PI fijo frente a PI con ajuste TSK-1. Si el docente exige accion derivativa no
nula, debe sintonizarse primero un PID nominal termico y volver a validar ambos modos.

Las ganancias positivas/acotadas y las simulaciones no constituyen una prueba formal de
estabilidad del sistema con ganancias variables. Esta es una base de pruebas, no una
sintonizacion optima ni una afirmacion de mejora universal.

## Temporizadores y limites de ejecucion

Motor: Timer1 conserva el PWM en D9, Timer0 proporciona el reloj de 4 us y Timer2 genera
ticks de 1 ms; cada 20 ticks se ejecuta el control completo dentro de la ISR.
Termica: Timer0 genera PWM en D5, Timer1 genera directamente el evento de 1 s y Timer2
proporciona el reloj de 4 us. Las conversiones ADC se realizan dentro de la ISR de control.

Durante los calculos se permiten interrupciones breves para mantener el encoder, reloj y
recepcion UART. Un guard impide la reentrada al controlador y apaga la salida si se incumple
un plazo de control. El ciclo principal solo procesa comandos y transmite muestras encoladas.
`control_us` registra tiempo de pared aproximado del lazo (incluye adquisicion e interrupciones,
excluye parte del prologo/epilogo); verificar el pulso D12 con osciloscopio o analizador logico.
La periodicidad y el peor tiempo de ejecucion reales aun deben medirse en la placa.

La salida inicia apagada. Python envia PING cada segundo; sin actividad PING por 5 s se
apaga al siguiente tick de control. STOP apaga inmediatamente al procesarse en el main.
La termica tiene corte a 80 C y rechazo de lectura menor a 1 C; esto no detecta todos los
fallos posibles del sensor. El ensayo termina automaticamente tras su duracion configurada.

Codigos de fin: 1=plazo incumplido; 2=temperatura/lectura; 3=timeout del enlace;
4=STOP; 5=duracion completada. Solo el codigo 5 se marca como captura completa.
La duracion maxima por ensayo es 3600 s. El firmware no calcula indices dentro de la ISR:
se calculan en Python a partir del registro completo.

## Simulacion y alcance de la validacion

```powershell
& "C:\Python314\python.exe" simular.py
```

Se utilizan las funciones de transferencia de la imagen, discretizadas con retencion de
orden cero, el controlador digital, saturacion y cuantizacion de PWM. El motor se simula
desde reposo; en termica se usa un modelo incremental alrededor de 28.4825 C, con entrada
base cero. Se supone medicion ideal: no se reproducen ruido, encoder, ADC, rozamiento,
tiempos de ISR ni todos los efectos fisicos. El cero positivo del modelo del motor produce
una respuesta inversa inicial que debe contrastarse con los datos medidos.

Supuesto pendiente de confirmar: la funcion termica representa cambios de temperatura
respecto del equilibrio. Si MATLAB se identifico con temperaturas absolutas sin tratar el
offset ambiental, revisar ese preprocesamiento antes de interpretar estas simulaciones
como predicciones cuantitativas. El firmware mide temperatura absoluta y usa r-T; no suma
ningun offset artificial a la medicion real.

Escenarios: escalon, dos cambios de referencia y perturbacion equivalente aditiva de entrada
(-20 unidades PWM motor o -5 puntos porcentuales termica, entre el 50 y 70 % del ensayo).
Esa perturbacion es una construccion matematica; no equivale automaticamente a una carga
mecanica o un ventilador reales. Comparar los resultados completos, incluso cuando el
hibrido empeora algun indicador.

Los modelos TS proporcionados representan las plantas, no el supervisor. No se incluyen
en el lazo: sus reglas centrales tienen coeficientes nulos y carecen de datos identificatorios.
Tampoco se convierten los resultados de simulacion en evidencias experimentales.

Fuentes de requisitos: PDF Lab_Fuzzy_PID-Hibrido (1), clase
https://lord-jebus.github.io/ILOG-Mat2/clase20/Clase15.html, imagen de modelos y ganancias,
y los dos programas de adquisicion aportados por el usuario.

# Verificacion de esta entrega

Firmware compilado con AVR-GCC 7.3.0, -std=gnu11 -Os -Wall -Wextra -Werror; cero advertencias.

| Planta | Programa [bytes] | RAM estatica [bytes] |
|---|---:|---:|
| Motor | 11996 | 423 |
| Termica | 11792 | 413 |

La RAM estatica no incluye el maximo de pila. No se midio el peor tiempo real de ISR.

Pruebas numericas y de protocolo: cobertura de pertenencias, limites de ganancias, anti-windup, integrales con senal conocida, captura normal, rechazo de huecos, rechazo de planta incorrecta y envio de STOP. No se abrieron puertos fisicos.

Resultados del escalon en simulacion ideal (no experimentales):

| Planta | Modo | IAE | Sobreimpulso [%] | Establecimiento [s] |
|---|---|---:|---:|---:|
| motor | PID | 39.9383 | 17.9852 | 2.18 |
| motor | HYB | 40.2580 | 16.8919 | 2.2 |
| termica | PID | 1236.6413 | 6.6263 | 435.0 |
| termica | HYB | 1236.5940 | 6.9203 | 437.0 |

El hibrido no mejora todos los indicadores. Son reglas iniciales para validar y ajustar en banco.
Se conserva Kd=0 en termica: PI fijo frente a PI hibrido.
Ver los supuestos del modelo termico, filtros y escalas en LEEME.md.

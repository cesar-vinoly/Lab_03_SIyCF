"""Compara CSV con el mismo horizonte, referencia y periodo de muestreo."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np

def load_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError(f'CSV vacio: {path}')
    data = {k: np.array([r[k] for r in rows], dtype=str if k == 'mode' else float) for k in rows[0]}
    for k, values in data.items():
        if k != 'mode' and not np.all(np.isfinite(values)):
            raise ValueError(f'Datos no finitos en {k}: {path}')
    if len(set(data['mode'])) != 1:
        raise ValueError('Hay varios modos en un CSV.')
    if np.any(data['missed']) or np.any(data['tx_dropped']):
        raise ValueError('CSV con plazos incumplidos o muestras perdidas.')
    active = np.flatnonzero(data['phase'] == 1)
    if len(active) < 3 or data['phase'][-1] != 2:
        raise ValueError('Faltan el tramo de control o la muestra de cierre.')
    for k in data:
        data[k] = data[k][active[0]:]
    data['t_s'] = data['t_s'] - data['t_s'][0]
    dt = np.diff(data['t_s'])
    if np.any(dt <= 0) or not np.allclose(dt, np.median(dt), rtol=0, atol=1e-5):
        raise ValueError('Muestreo irregular; no se interpolan ni se inventan muestras.')
    # Metadatos de captura prevalecen sobre una fila final aislada.
    meta = Path(path).with_suffix('.json')
    if meta.exists():
        info = json.loads(meta.read_text(encoding='utf-8'))
        if info.get('estado') not in (None, 'completo'):
            raise ValueError('Captura incompleta segun los metadatos.')
    return data

def metrics(d, hold_s=1.0, band_fraction=0.02):
    t,y,r,u = (d[k] for k in ['t_s','y','ref','u'])
    error = r-y
    result = {'horizonte_s':float(t[-1]-t[0]), 'Ts_s':float(np.median(np.diff(t))),
              'IAE':float(np.trapezoid(abs(error), t)),
              'ISE':float(np.trapezoid(error**2, t)),
              'ITAE':float(np.trapezoid((t-t[0])*abs(error), t)),
              'esfuerzo_integral_u2':float(np.sum(u[:-1]**2*np.diff(t))),
              'variacion_total_u':float(np.sum(abs(np.diff(u[:-1])))),
              'Ju':float(np.sum(np.diff(u[:-1])**2)),
              'control_us_max':float(np.max(d['control_us']))}
    result.update(sobreimpulso_pct=None, establecimiento_s=None, subida_10_90_s=None,
                  error_final_medio=None, banda_absoluta=None)
    if np.allclose(r, r[0], rtol=0, atol=1e-6):
        step = r[0]-y[0]
        tail = max(1, int(np.ceil(len(y)*0.1)))
        result['error_final_medio'] = float(np.mean(error[-tail:]))
        if abs(step) > 1e-9:
            progress = (y-y[0])/step
            result['sobreimpulso_pct'] = float(max(0, np.max(progress)-1)*100)
            band = band_fraction*abs(step)
            result['banda_absoluta'] = float(band)
            outside = np.flatnonzero(abs(error)>band)
            index = int(outside[-1]+1) if len(outside) else 0
            if index < len(t) and t[-1]-t[index] >= hold_s:
                result['establecimiento_s'] = float(t[index]-t[0])
            ten, ninety = np.flatnonzero(progress>=0.1), np.flatnonzero(progress>=0.9)
            if len(ten) and len(ninety):
                result['subida_10_90_s'] = float(t[ninety[0]]-t[ten[0]])
    return result

def plot_comparison(first, second, out, plant, title=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':10, 'axes.grid':True, 'grid.alpha':0.25})
    fig, axes = plt.subplots(3, 1, figsize=(10,8), sharex=True, constrained_layout=True)
    if title: fig.suptitle(title)
    for d, label, color in [(first,'Clasico','#2166ac'),(second,'Hibrido TSK-1','#c65322')]:
        t = d['t_s']
        axes[0].plot(t,d['y'],label=label,color=color)
        axes[1].step(t,d['u'],where='post',color=color,label=label)
        axes[2].plot(t,d['ref']-d['y'],color=color,label=label)
    axes[0].plot(first['t_s'],first['ref'],'--',color='#333333',label='Referencia')
    axes[0].set_ylabel('Velocidad [rpm]' if plant=='motor' else 'Temperatura [°C]')
    axes[1].set_ylabel('PWM [0–255]' if plant=='motor' else 'Potencia [%]')
    axes[2].set_ylabel('Error'); axes[2].set_xlabel('Tiempo desde inicio del control [s]')
    axes[0].legend(); fig.savefig(out/'comparacion.png',dpi=180); plt.close(fig)
    fig, axes = plt.subplots(3,1,figsize=(10,7),sharex=True,constrained_layout=True)
    if title: fig.suptitle(title)
    for ax, key in zip(axes,['kp','ki','kd']):
        ax.plot(first['t_s'],first[key],label='Clasico',color='#2166ac')
        ax.plot(second['t_s'],second[key],label='Hibrido',color='#c65322')
        ax.set_ylabel(key)
    axes[0].legend(); axes[-1].set_xlabel('Tiempo [s]')
    fig.savefig(out/'ganancias.png',dpi=180); plt.close(fig)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('clasico',type=Path); p.add_argument('hibrido',type=Path)
    p.add_argument('--planta',choices=['motor','termica'],required=True)
    p.add_argument('--salida',type=Path,default=Path('comparacion'))
    p.add_argument('--tolerancia-inicial',type=float,default=0.5)
    p.add_argument('--permanencia',type=float,default=None)
    a=p.parse_args()
    x,y=load_csv(a.clasico),load_csv(a.hibrido)
    if set(x['mode'])!={'PID'} or set(y['mode'])!={'HYB'}:
        p.error('Indicar primero el CSV clasico y despues el hibrido.')
    if len(x['t_s'])!=len(y['t_s']) or not np.allclose(x['t_s'],y['t_s'],rtol=0,atol=1e-5):
        p.error('Los horizontes o periodos de muestreo son diferentes.')
    if not np.allclose(x['ref'],y['ref'],rtol=0,atol=1e-5):
        p.error('Las referencias o instantes de cambio no coinciden.')
    if abs(x['y'][0]-y['y'][0])>a.tolerancia_inicial:
        p.error('Condiciones iniciales diferentes: repetir el ensayo desde un estado equivalente.')
    a.salida.mkdir(parents=True,exist_ok=True)
    hold=a.permanencia if a.permanencia is not None else (1 if a.planta=='motor' else 30)
    mx,my=metrics(x,hold),metrics(y,hold)
    with (a.salida/'metricas.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(['indicador','clasico','hibrido'])
        for k in mx:w.writerow([k,mx[k],my[k]])
    (a.salida/'metricas.json').write_text(json.dumps({'planta':a.planta,'clasico':mx,'hibrido':my,
        'nota':'null = no alcanzado/no aplicable. Error final no demuestra estado estacionario.',
        'banda_porcentaje_escalon':2,'permanencia_minima_s':hold},indent=2),encoding='utf-8')
    plot_comparison(x,y,a.salida,a.planta)
    print(json.dumps({'clasico':mx,'hibrido':my},indent=2))

if __name__=='__main__': main()

"""Pruebas de protocolo sin abrir puertos fisicos, e indices con senales conocidas."""
import contextlib
import csv
import io
import json
from pathlib import Path
import sys
import tempfile
import types
import numpy as np
import capturar
from metricas import load_csv
from simular import verify

class FakeSerial:
    variant='normal'
    instances=[]
    def __init__(self,*args,**kwargs):
        self.lines=[];self.commands=[];self.instances.append(self)
    def reset_input_buffer(self):self.lines=[]
    def write(self,b):
        text=b.decode().strip();self.commands.append(text)
        if text=='?':
            plant='termica' if self.variant=='planta_incorrecta' else 'motor'
            self.lines=[f'#READY {plant} Ts_ms=20 baud=115200',','.join(capturar.FIELDS)]
        elif text.startswith('START '):
            self.lines=['#ACCEPTED START']
            for k in range(151):
                if self.variant=='hueco' and k==110:continue
                t=round(k*.02,3);phase=0 if k<100 else (1 if k<150 else 2)
                row=[t,phase,'PID',0,80,0,0,80,.8356,5.498,.03175,500,0,0]
                self.lines.append(','.join(map(str,row)))
            self.lines.append('#FIN 5')
    def readline(self):return ((self.lines.pop(0)+'\n').encode() if self.lines else b'')
    def flush(self):pass
    def close(self):pass

def main():
    verify()
    old_serial=sys.modules.get('serial');old_sleep=capturar.time.sleep;old_argv=sys.argv
    sys.modules['serial']=types.SimpleNamespace(Serial=FakeSerial)
    capturar.time.sleep=lambda _:None
    try:
        test_root=Path(__file__).resolve().parent
        with tempfile.TemporaryDirectory(prefix='lab_pid_test_',dir=test_root) as tmp:
            assert Path(tmp).resolve().is_relative_to(test_root)
            for variant in ['normal','hueco','planta_incorrecta']:
                FakeSerial.variant=variant;out=Path(tmp)/(variant+'.csv')
                sys.argv=['capturar.py','--puerto','FAKE','--planta','motor','--modo','PID',
                    '--referencia','80','--duracion','1','--salida',str(out)]
                failed=False
                with contextlib.redirect_stdout(io.StringIO()):
                    try:capturar.main()
                    except SystemExit:failed=True
                assert failed==(variant!='normal')
                meta=json.loads(out.with_suffix('.json').read_text())
                assert (meta['estado']=='completo')==(variant=='normal')
                assert 'STOP' in FakeSerial.instances[-1].commands
                if variant=='normal':
                    d=load_csv(out)
                    assert len(d['t_s'])==51 and np.isclose(d['t_s'][-1],1)
                else:
                    try:load_csv(out)
                    except ValueError:pass
                    else:raise AssertionError('Se acepto una captura incompleta.')
    finally:
        if old_serial is None:sys.modules.pop('serial',None)
        else:sys.modules['serial']=old_serial
        capturar.time.sleep=old_sleep;sys.argv=old_argv
    print('OK: normalizacion, limites, anti-windup, indices, protocolo normal, perdida de muestras, planta incorrecta y STOP.')

if __name__=='__main__':main()
